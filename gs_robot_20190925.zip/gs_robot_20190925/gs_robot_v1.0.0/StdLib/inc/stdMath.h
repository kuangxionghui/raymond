/**
  ******************************************************************************
  * @file    stdMath.h
  * @author  Zzl
  * @version V1.0.0
  * @date    2015-06-03
  * @brief   ���ļ���ģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ���������ơ�
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STD_MATH_H
#define __STD_MATH_H

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"

/* Exported Macro ------------------------------------------------------------*/
#define 	STD_PI		3.141592654f		//Բ���� float

/* Exported Types ------------------------------------------------------------*/

/* Exported Variables --------------------------------------------------------*/

/* Exported Function Prototypes ----------------------------------------------*/
float 	stdMath_Max(float a, float b);
float 	stdMath_Min(float a, float b);
float 	stdMath_fabsMax(float a, float b);
float 	stdMath_fabsMin(float a, float b);

void  	stdMath_Swap(float* a, float* b);
float 	stdMath_Limit(float data, float limit1, float limit2);

u8 		stdMath_Polar(u8 polar, u8 data);
float 	stdMath_Sign(float x, s8 mode);

#ifdef __cplusplus
}
#endif

#endif /* __STD_MATH_H */ 

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
