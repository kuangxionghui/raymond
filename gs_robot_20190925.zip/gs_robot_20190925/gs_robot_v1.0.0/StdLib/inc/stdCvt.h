/**
  ******************************************************************************
  * @file    stdCvt.h
  * @author  Zzl
  * @version V1.0.0
  * @date    2015-06-03
  * @brief   ���ļ���ģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ���������ơ�
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STD_CONVERT_H
#define __STD_CONVERT_H

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"

/* Exported Macro ------------------------------------------------------------*/
/* Exported Types ------------------------------------------------------------*/

/* Exported Variables --------------------------------------------------------*/

/* Exported Function Prototypes ----------------------------------------------*/
float 	stdCvt_MillimeterToMeter(float mm);
float 	stdCvt_MeterToMillimeter(float m);

float 	stdCvt_RadianLimit(float Rad);
float 	stdCvt_AngleLimit(float angle);
float 	stdCvt_Radian(float angle);
float 	stdCvt_Angle(float rad);

u32 	stdCvt_ByteToInt_HighFirst(u8 mode, u8 tab[], u16 *index, u8 len);
void 	stdCvt_IntToByte_HighFirst(u8 mode, u8 tab[], u16 *index, u8 len, u32 data);
u32 	stdCvt_ByteToInt_LowFirst(u8 mode, u8 tab[], u16 *index, u8 len);
void 	stdCvt_IntToByte_LowFirst(u8 mode, u8 tab[], u16 *index, u8 len, u32 data);

char    stdCvt_NumToASCII(char num);
char    stdCvt_ASCIIToNum(char ascII);
#ifdef __cplusplus
}
#endif

#endif /* __STD_CONVERT_H*/ 

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
