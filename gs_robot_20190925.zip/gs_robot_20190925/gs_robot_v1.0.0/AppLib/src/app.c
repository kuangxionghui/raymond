/**
  ******************************************************************************
  * @file    app.c
  * @author  kuang
  * @version V1.0.0
  * @date    2019-06-14
  * @brief   ���ļ���ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ�������
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "app.h"
#include "dev.h"
#include "devPcCommunication.h"
#include "bsp.h"
#include "devRemoteControl.h"
#include <math.h>
#include "devTim310.h"
#include "devAntiBar.h"
#include "devEmergencyButton.h"
#include "devAgvBat.h"
/* Private Macro -------------------------------------------------------------*/ 
/* Private Types -------------------------------------------------------------*/
App_T s_app;

extern PcCom_T s_pcCom;
extern RemoteCtl_T s_remoteCtl;
extern SteerWheel_T s_steerWheel;
extern ReadCard_T s_readCard;
extern Tim310 s_tim310;
extern AntiBar s_antiBar;
extern Emergency_T s_emergency;
extern AgvBat_T s_agvBat;

/* Exported Variables Defines-------------------------------------------------*/
#define NAV_STATE_IDLE         0x00
#define NAV_STATE_START        0x01
#define NAV_STATE_FORWORD      0x02
#define NAV_STATE_BACK         0x03
#define NAV_STATE_LEFT         0x04
#define NAV_STATE_RIGHT        0x05
#define NAV_STATE_STOP         0x06

#define MOVE_FORWORD  0x01
#define MOVE_BACK     0x00

#define FORK_FORWORD  0x00
#define FORK_LEFT     0x01
#define FORK_RIGHT    0x02

#define MOTION_STOP            0x00
#define MOTION_FORWOED         0x01
#define MOTION_BACK            0x02
#define MOTION_SPEED_SLOWLY    0x03
#define MOTION_SPEED_NORMAL    0x04
#define MOTION_TURN_LEFT       0x05
#define MOTION_TURN_RIGHT      0x06

#define SENSOR_MAX_OFFSET      8

/* Private Variables ---------------------------------------------------------*/

u16 df_delay_cnt = 0;

/* Private Function Prototypes -----------------------------------------------*/
/* Function Defines ----------------------------------------------------------*/

/** @brief  		ģ���ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void app_Init(void)
{
	s_app.Enable = 1;
  s_app.OutWayFlag = 0;
}

/** @brief  		ѭ������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void app_Loop(void)
{
	if(s_app.Enable == 0)
		return;
	
	taskMoveControl();
	taskLedControl();
	taskCheckSafe();
}

/** @brief  		�˶�����
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void taskMoveControl(void)
{
	if((s_pcCom.StartFlag == 1)&&(s_steerWheel.InitCmpFlag == 1))
	{
		switch(s_pcCom.CtrMode)
		{
			case 0x00:                        //����
				check_nav_control();
				break;
			
			case 0x01:                        //ң��
				check_outline_control();
				break;
			
			case 0x02:
				check_panel_control();          //��Ļ����
				break;
		}
  }
}

/** @brief  		����ģʽ
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void check_nav_control(void)
{  
	if(s_pcCom.NavRunFlag == 1)
	{
		switch(s_pcCom.TaskIdx)
		{
			case 0x00:
				
				nav_control_forword();
				break;
			
			case 0x01:
				nav_control_back();
				break;
			
			case 0x02:
				nav_control_turn_left_90();
				break;
			
			case 0x03:
				nav_control_turn_right_90();
				break;
			
			case 0x04:
				nav_control_dirft_left();
			  break;
			
			case 0x05:
				nav_control_dirft_right();
			  break;
			
			case 0x06:
				nav_control_turn_round();
				break;
			
			case 0x07:
				nav_control_stop();
				break;
			
			case 0x08:
				nav_front_station();
				break;
			
			case 0x09:
				nav_back_station();
				break;
		}
	}
}

/** @brief  		��������һ�ſ�
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void nav_front_station(void)
{
	s_steerWheel.Vel_x = 2*100;
	
	//���ϼ��
	
	if((s_tim310.FrontEnable == 1) && (s_tim310.FrontValue <= s_tim310.FrontStopValue))
	{
		
		s_steerWheel.Vel_x = 0;
	}
  s_steerWheel.CtlMode = CONTROL_MODE_NAV;
	s_steerWheel.StateMode = RUN_MODE_ENABLE;
	s_steerWheel.MoveDir = 0x01;	  //ǰ��
	s_steerWheel.ForkMode = 0x00;
	sMove_nav_updata();
	if(s_readCard.GetNewCard == 1)
	{
		s_readCard.GetNewCard = 0;
		s_pcCom.TaskCompleteFlag = 1;  //�������
		s_pcCom.NavRunFlag = 0;
		s_steerWheel.Vel_x = 0;
		s_steerWheel.StateMode = RUN_MODE_STOP;
		sMove_nav_updata();
	}
}

/** @brief  		��������һ�ſ�
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void nav_back_station(void)
{
	s_steerWheel.Vel_x = 2*100;
	
	//���ϼ��
	
	if((s_tim310.FrontEnable == 1) && (s_tim310.FrontValue <= s_tim310.FrontStopValue))
	{
		s_steerWheel.Vel_x = 0;
	}
  s_steerWheel.CtlMode = CONTROL_MODE_NAV;
	s_steerWheel.StateMode = RUN_MODE_ENABLE;
	s_steerWheel.MoveDir = 0x00;	  //����
	s_steerWheel.ForkMode = 0x00;
	sMove_nav_updata();
	if(s_readCard.GetNewCard == 1)
	{
		s_readCard.GetNewCard = 0;
		s_pcCom.TaskCompleteFlag = 1;  //�������
		s_pcCom.NavRunFlag = 0;
		s_steerWheel.Vel_x = 0;
		s_steerWheel.StateMode = RUN_MODE_STOP;
		sMove_nav_updata();
	}
}

/** @brief  		����ǰ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void nav_control_forword(void)
{
	s_steerWheel.Vel_x = s_pcCom.Vel_x*100;
	
	//���ϼ��
	if((s_tim310.FrontEnable == 1) && (s_tim310.FrontValue <= s_tim310.FrontSlowlyValue) && (s_tim310.FrontValue > s_tim310.FrontStopValue))
	{
		s_tim310.Obstacle = 1;
		if(s_steerWheel.Vel_x >= 250)
		{
			s_steerWheel.Vel_x = 250;
		}
	}
	else if((s_tim310.FrontEnable == 1) && (s_tim310.FrontValue <= s_tim310.FrontStopValue))
	{
		s_tim310.Obstacle = 2;
		s_steerWheel.Vel_x = 0;
	}
	else
	{
		s_tim310.Obstacle = 0;
	}
	
	//���ټ��
	if(s_pcCom.SlowFlag == 1)
	{
		if(s_steerWheel.Vel_x >= 200)
		{
			s_steerWheel.Vel_x = 200;
		}
	}
	
	//������ѹ���
	if(s_pcCom.PickUp == 1)   //�Ƿ��ڲֿ���
	{
		if((s_steerWheel.SensorOffset_f > SENSOR_MAX_OFFSET)||(s_steerWheel.SensorOffset_f < -SENSOR_MAX_OFFSET))  //���������ƫ��,ͣ��
		{
			s_app.OutWayFlag = 1;
			s_steerWheel.Vel_x = 0;		
		}
		else
		{
			s_app.OutWayFlag = 0;
		}
	}
	else
	{
		s_app.OutWayFlag = 0;
	}
	
	s_steerWheel.CtlMode = CONTROL_MODE_NAV;
	s_steerWheel.StateMode = RUN_MODE_ENABLE;
	s_steerWheel.MoveDir = 0x01;	  //ǰ��
	s_steerWheel.ForkMode = 0x00;
	sMove_nav_updata();
	
	if((s_readCard.ID_h == s_pcCom.TargetCard_h)&&(s_readCard.ID_l == s_pcCom.TargetCard_l))
	{
		s_pcCom.TaskCompleteFlag = 1;  //�������
		s_pcCom.NavRunFlag = 0;
		s_steerWheel.Vel_x = 0;
		s_steerWheel.StateMode = RUN_MODE_STOP;
		sMove_nav_updata();
	}
}

/** @brief  		��������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void nav_control_back(void)
{
	s_steerWheel.Vel_x = s_pcCom.Vel_x*100;
	
	//�ϰ�����
	if((s_tim310.BackEnable == 1) && (s_tim310.BackValue <= s_tim310.BackSlowlyValue) && (s_tim310.BackValue > s_tim310.BackStopValue))
	{
		s_tim310.Obstacle = 1;
		if(s_steerWheel.Vel_x >= 250)
		{
			s_steerWheel.Vel_x = 250;
		}
	}
	else if((s_tim310.BackEnable == 1) && (s_tim310.BackValue <= s_tim310.BackStopValue))
	{
		s_tim310.Obstacle = 2;
		s_steerWheel.Vel_x = 0;
	}
	else
	{
		s_tim310.Obstacle = 0;
	}
	
	//���ټ��
	if(s_pcCom.SlowFlag == 1)
	{
		if(s_steerWheel.Vel_x >= 200)
		{
			s_steerWheel.Vel_x = 200;
		}
	}
	
	//������ѹ���
	if(s_pcCom.PickUp == 1)   //�Ƿ��������
	{
		if((s_steerWheel.SensorOffset_f > SENSOR_MAX_OFFSET)||(s_steerWheel.SensorOffset_f < -SENSOR_MAX_OFFSET))  //���������ƫ��,ͣ��
		{
			s_app.OutWayFlag = 1;
			s_steerWheel.Vel_x = 0;		
		}
		else
		{
			s_app.OutWayFlag = 0;
		}
	}
	else
	{
		s_app.OutWayFlag = 0;
	}
	
	s_steerWheel.CtlMode = CONTROL_MODE_NAV;
	s_steerWheel.StateMode = RUN_MODE_ENABLE;
	s_steerWheel.MoveDir = 0x00;	 //����
	s_steerWheel.ForkMode = 0x00;
	sMove_nav_updata();
	
	if((s_readCard.ID_h == s_pcCom.TargetCard_h)&&(s_readCard.ID_l == s_pcCom.TargetCard_l))
	{
		s_pcCom.TaskCompleteFlag = 1;  //�������
		s_pcCom.NavRunFlag = 0;
		s_steerWheel.Vel_x = 0;
		s_steerWheel.StateMode = RUN_MODE_STOP;
		sMove_nav_updata();
	}
}

/** @brief  		���������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void nav_control_dirft_left(void)
{
	s_steerWheel.Vel_x = s_pcCom.Vel_x*100;
	
	//���ټ��
	if(s_pcCom.SlowFlag == 1)
	{
		if(s_steerWheel.Vel_x >= 200)
		{
			s_steerWheel.Vel_x = 200;
		}
	}
	
	//�ѹ���
	if((s_steerWheel.SensorFlag_f == 0x00)&&(s_steerWheel.SensorFlag_l == 0x00)&&(s_steerWheel.SensorFlag_r == 0x00))
	{
		s_app.OutWayFlag = 1;
		s_steerWheel.Vel_x = 0;
	}
	
	s_steerWheel.CtlMode = CONTROL_MODE_DIRFT;
	s_steerWheel.StateMode = RUN_MODE_ENABLE;
	s_steerWheel.MoveDir = 0x01;
	s_steerWheel.DirftMode = 0x02;              //�ŵ�������ģʽ
	s_steerWheel.ForkMode = 0x00;               //Ʈ��
	s_steerWheel.Angle = 9000;
	sMove_dirft_updata();
	
	if((s_readCard.ID_h == s_pcCom.TargetCard_h)&&(s_readCard.ID_l == s_pcCom.TargetCard_l))
	{
		s_pcCom.TaskCompleteFlag = 1;  //�������
		s_pcCom.NavRunFlag = 0;
		s_steerWheel.Vel_x = 0;
		s_steerWheel.StateMode = RUN_MODE_BRAKE;
		sMove_nav_updata();
	}
}

/** @brief  		�����Ҳ���
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void nav_control_dirft_right(void)
{
	s_steerWheel.Vel_x = s_pcCom.Vel_x*100;
	
	//���ټ��
	if(s_pcCom.SlowFlag == 1)
	{
		if(s_steerWheel.Vel_x >= 200)
		{
			s_steerWheel.Vel_x = 200;
		}
	} 
	
	//�ѹ���
	if((s_steerWheel.SensorFlag_f == 0x00)&&(s_steerWheel.SensorFlag_l == 0x00)&&(s_steerWheel.SensorFlag_r == 0x00))
	{
		s_app.OutWayFlag = 1;
		s_steerWheel.Vel_x = 0;
	}
	
	s_steerWheel.CtlMode = CONTROL_MODE_DIRFT;
	s_steerWheel.StateMode = RUN_MODE_ENABLE;
	s_steerWheel.MoveDir = 0x00;
	s_steerWheel.DirftMode = 0x02;              //�ŵ�������ģʽ
	s_steerWheel.ForkMode = 0x00;               //Ʈ��
	s_steerWheel.Angle = 9000;
	sMove_dirft_updata();
	
	if((s_readCard.ID_h == s_pcCom.TargetCard_h)&&(s_readCard.ID_l == s_pcCom.TargetCard_l))
	{
		s_pcCom.TaskCompleteFlag = 1;  //�������
		s_pcCom.NavRunFlag = 0;
		s_steerWheel.Vel_x = 0;
		s_steerWheel.StateMode = RUN_MODE_BRAKE;
		sMove_nav_updata();
	}
}

/** @brief  		������ת90��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void nav_control_turn_left_90(void)
{
	static u8 turn_state = 0x00;
	static u16 delay_cnt = 0;
	static u32 current_ecode_cnt = 0;
	static u32 last_ecode_cnt = 0;
	static u16 ecode_cnt = 0;
	
	switch(turn_state)
	{
		case 0x00:
			s_pcCom.TaskCompleteFlag = 0;
			s_steerWheel.CtlMode = CONTROL_MODE_TURN;
      s_steerWheel.StateMode = RUN_MODE_ENABLE;		
		  s_steerWheel.TurnDir = 0x01;
		  s_steerWheel.TurnMode = 0x01;
		  s_steerWheel.Vel_x = 300; //s_pcCom.Vel_x*100;
		  sMove_turn_updata();
		  last_ecode_cnt = s_steerWheel.EncodeCnt_1;
		  if(s_steerWheel.SensorFlag_f == 0x00)
			{
				delay_cnt++;
				if(delay_cnt > 100)
				{
					delay_cnt = 0;
					turn_state = 0x01;
				}
			}
			else
			{
				delay_cnt = 0;
			}
			break;
			
		case 0x01:
			s_steerWheel.CtlMode = CONTROL_MODE_TURN;
      s_steerWheel.StateMode = RUN_MODE_ENABLE;		
		  s_steerWheel.TurnDir = 0x01;
		  s_steerWheel.TurnMode = 0x01;
		  s_steerWheel.Vel_x = 300; //s_pcCom.Vel_x*100;
		  sMove_turn_updata();
			current_ecode_cnt = s_steerWheel.EncodeCnt_1;
		  ecode_cnt = fabs(current_ecode_cnt - last_ecode_cnt);
		  if(ecode_cnt > 30)
			{
				ecode_cnt = 0;
				turn_state = 0x02;
			}
			break;
			
		case 0x02:
			s_steerWheel.CtlMode = CONTROL_MODE_NAV;
			s_steerWheel.StateMode = RUN_MODE_ENABLE;
			s_steerWheel.MoveDir = 0x01;	  //ǰ��
			s_steerWheel.ForkMode = 0x00;
		  s_steerWheel.Vel_x = 0;
			sMove_nav_updata();
      if(s_steerWheel.SensorFlag_f == 1)
			{
				if((s_steerWheel.SensorOffset_f <= 10)&&(s_steerWheel.SensorOffset_f >= -10))
				{
					
					turn_state = 0x03;
					s_steerWheel.Vel_x = 0;
					sMove_nav_updata();
				}
			}
			s_pcCom.TaskCompleteFlag = 0;
			break;
			
		case 0x03:
			delay_cnt++;
			if(delay_cnt > 100)
			{
				delay_cnt = 0;
				turn_state = 0x04;
			}
			s_steerWheel.CtlMode = CONTROL_MODE_NAV;
			s_steerWheel.StateMode = RUN_MODE_ENABLE;
			s_steerWheel.MoveDir = 0x01;	  //ǰ��
			s_steerWheel.ForkMode = 0x00;
			sMove_nav_updata();
			s_pcCom.TaskCompleteFlag = 0;
			break;
		
		case 0x04:
			s_steerWheel.CtlMode = CONTROL_MODE_NAV;
		  s_steerWheel.StateMode = RUN_MODE_ENABLE;
			s_steerWheel.MoveDir = 0x01;	  //ǰ��
			s_steerWheel.ForkMode = 0x00;
			sMove_nav_updata();
		  s_pcCom.TaskCompleteFlag = 1;
			s_pcCom.NavRunFlag = 0;
			s_steerWheel.Vel_x = 0;
			sMove_nav_updata();
		  turn_state = 0x00;
			break;
	}
}

/** @brief  		������ת90��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void nav_control_turn_right_90(void)
{
	static u8 turn_state = 0x00;
  static u16 delay_cnt = 0;
	static u32 current_ecode_cnt = 0;
	static u32 last_ecode_cnt = 0;
	static u16 ecode_cnt = 0;
	
	switch(turn_state)
	{
		case 0x00:
			s_pcCom.TaskCompleteFlag = 0;
			s_steerWheel.CtlMode = CONTROL_MODE_TURN;
      s_steerWheel.StateMode = RUN_MODE_ENABLE;		
		  s_steerWheel.TurnDir = 0x00;
		  s_steerWheel.TurnMode = 0x01;
		  s_steerWheel.Vel_x = 300;//s_pcCom.Vel_x*100;
		  sMove_turn_updata();
		  if(s_steerWheel.SensorFlag_f == 0x00)
			{
				delay_cnt++;
				if(delay_cnt > 100)
				{
					delay_cnt = 0;
					turn_state = 0x01;
				}
			}
			else
			{
				delay_cnt = 0;
			}
			break;
			
		case 0x01:
			s_steerWheel.CtlMode = CONTROL_MODE_TURN;
      s_steerWheel.StateMode = RUN_MODE_ENABLE;		
		  s_steerWheel.TurnDir = 0x00;
		  s_steerWheel.TurnMode = 0x01;
		  s_steerWheel.Vel_x = 300; //s_pcCom.Vel_x*100;
		  sMove_turn_updata();
			current_ecode_cnt = s_steerWheel.EncodeCnt_1;
		  ecode_cnt = fabs(current_ecode_cnt - last_ecode_cnt);
		  if(ecode_cnt > 30)
			{
				ecode_cnt = 0;
				turn_state = 0x02;
			}
			break;
			
		case 0x02:
			s_steerWheel.CtlMode = CONTROL_MODE_NAV;
			s_steerWheel.StateMode = RUN_MODE_ENABLE;
			s_steerWheel.MoveDir = 0x01;	  //ǰ��
			s_steerWheel.ForkMode = 0x00;
		  s_steerWheel.Vel_x = 0;
			sMove_nav_updata();
      if(s_steerWheel.SensorFlag_f == 1)
			{
				if((s_steerWheel.SensorOffset_f <= 10)&&(s_steerWheel.SensorOffset_f >= -10))
				{
					
					turn_state = 0x03;
					s_steerWheel.Vel_x = 0;
					sMove_nav_updata();
				}
			}
			s_pcCom.TaskCompleteFlag = 0;
			break;
		
		case 0x03:
			delay_cnt++;
			if(delay_cnt > 100)
			{
				delay_cnt = 0;
				turn_state = 0x04;
			}
			s_steerWheel.CtlMode = CONTROL_MODE_NAV;
			s_steerWheel.StateMode = RUN_MODE_ENABLE;
			s_steerWheel.MoveDir = 0x01;	  //ǰ��
			s_steerWheel.ForkMode = 0x00;
			sMove_nav_updata();
			s_pcCom.TaskCompleteFlag = 0;
			break;	
			
		case 0x04:
			s_steerWheel.CtlMode = CONTROL_MODE_NAV;
		  s_steerWheel.StateMode = RUN_MODE_ENABLE;
			s_steerWheel.MoveDir = 0x01;	  //ǰ��
			s_steerWheel.ForkMode = 0x00;
			sMove_nav_updata();
		  s_pcCom.TaskCompleteFlag = 1;
			s_pcCom.NavRunFlag = 0;
			s_steerWheel.Vel_x = 0;
			sMove_nav_updata();
		  turn_state = 0x00;
			break;
	}
}

/** @brief  		������ͷ
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void nav_control_turn_round(void)
{
	nav_control_turn_right_90();
	/*
	static u8 turn_state = 0x00;

	switch(turn_state)
	{
		case 0x00:
			s_steerWheel.CtlMode = CONTROL_MODE_TURN;
      s_steerWheel.StateMode = RUN_MODE_ENABLE;		
		  s_steerWheel.TurnDir = 0x00;
		  s_steerWheel.TurnMode = 0x01;
		  s_steerWheel.Vel_x = 150;//s_pcCom.Vel_x*100;
		  sMove_turn_updata();
		  if(s_steerWheel.SensorFlag_f == 0x00)
			{
				turn_state = 0x01;
			}
			break;
			
		case 0x01:
			s_steerWheel.CtlMode = CONTROL_MODE_TURN;
      s_steerWheel.StateMode = RUN_MODE_ENABLE;		
		  s_steerWheel.TurnDir = 0x00;
		  s_steerWheel.TurnMode = 0x01;
		  s_steerWheel.Vel_x = 150; //s_pcCom.Vel_x*100;
		  sMove_turn_updata();
      if(s_steerWheel.SensorFlag_f == 1)
			{
				if(s_steerWheel.SensorOffset_f <= 6)
				{
					turn_state = 0x02;
				}
			}
			break;
	  
		case 0x02:
			s_steerWheel.CtlMode = CONTROL_MODE_TURN;
      s_steerWheel.StateMode = RUN_MODE_ENABLE;		
		  s_steerWheel.TurnDir = 0x00;
		  s_steerWheel.TurnMode = 0x01;
		  s_steerWheel.Vel_x = 150;//s_pcCom.Vel_x*100;
		  sMove_turn_updata();
		  if(s_steerWheel.SensorFlag_f == 0x00)
			{
				turn_state = 0x03;
			}
			break;	
			
		case 0x03:
			s_steerWheel.CtlMode = CONTROL_MODE_TURN;
      s_steerWheel.StateMode = RUN_MODE_ENABLE;		
		  s_steerWheel.TurnDir = 0x00;
		  s_steerWheel.TurnMode = 0x01;
		  s_steerWheel.Vel_x = 150; //s_pcCom.Vel_x*100;
		  sMove_turn_updata();
      if(s_steerWheel.SensorFlag_f == 1)
			{
				if(s_steerWheel.SensorOffset_f <= 6)
				{
					turn_state = 0x04;
				}
			}
			break;	
			
		case 0x04:
			s_steerWheel.CtlMode = CONTROL_MODE_TURN;		
		  s_steerWheel.TurnDir = 0x00;
		  s_steerWheel.TurnMode = 0x01;
		  s_pcCom.TaskCompleteFlag = 1;
			s_pcCom.NavRunFlag = 0;
			s_steerWheel.Vel_x = 0;
			s_steerWheel.StateMode = RUN_MODE_BRAKE; //RUN_MODE_BRAKE;
			sMove_turn_updata();
		  turn_state = 0x00;
			break;
	}
	*/
}

/** @brief  		����ֹͣ
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void nav_control_stop(void)
{
	s_steerWheel.Vel_x = 0;
	s_steerWheel.CtlMode = CONTROL_MODE_NAV;
	s_steerWheel.StateMode = RUN_MODE_ENABLE;
	s_steerWheel.MoveDir = 0x01;	  //ǰ��
	s_steerWheel.ForkMode = 0x00;
	sMove_nav_updata();
}

/** @brief  	LED����
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void taskLedControl(void)
{
	if((s_app.OutWayFlag==1)||(s_tim310.Obstacle==2)||(s_antiBar.flag==1)||(s_emergency.flag==1)||(s_pcCom.TimeOutFlag==1)||(s_pcCom.PauseFlag==1))
	{
		devLit_SetDisMode(9);  //���������ɫ����˸
	}
	else
	{
		if(s_agvBat.Power < 20)
		{
		  devLit_SetDisMode(11);   //�͵�ѹ��ɫ����˸
		}
		else
		{
			if(s_pcCom.Getboard == 1)
			{
				devLit_SetDisMode(7);    //ȡ������ɫ����˸
			}
			else
			{
				if(s_steerWheel.Vel_x == 0)
				{
					devLit_SetDisMode(8);   //ֹͣʱ��ɫ�Ƴ���
				}
				else if((s_steerWheel.Vel_x < 300)&&(s_steerWheel.Vel_x > 0))
				{
					devLit_SetDisMode(10);   //���л�ɫ��
				}
				else if(s_steerWheel.Vel_x >= 300)
				{
					devLit_SetDisMode(2);   //����������ɫ�Ƴ���
				}
		  }
	  }
	}
}

/** @brief  	��ȫ�������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void taskCheckSafe(void)
{
	if(s_tim310.Obstacle == 2)
	{
		devMp3_UserSet(28,28);    
	}
	else if(s_tim310.Obstacle == 1)
	{
		devMp3_UserSet(29,28);
	}
	else
	{
		if(s_agvBat.Power < 20)
		{
		  devMp3_UserSet(27,28);
		}
		else
		{
			if(s_steerWheel.Vel_x == 0)
		  {
				devMp3_UserSet(255,28);
		  }
			else
			{
				devMp3_UserSet(103,28);
			}
		}
	}
}

/** @brief  	��Ļң��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void check_panel_control(void)
{
	switch(s_pcCom.PanelRemoto)
	{
		case 0x06:
			s_steerWheel.Vel_x = 0;
			s_steerWheel.Angle = 0;
			s_steerWheel.CtlMode = CONTROL_MODE_MANUAL;
			s_steerWheel.StateMode = RUN_MODE_BRAKE;    //ɲ��
			sMove_manual_updata();
			break;
		
		case 0x00:
			s_steerWheel.MoveDir = 0x01;     //ǰ��
			s_steerWheel.TurnDir = 0x00;
			s_steerWheel.DirftOn = 0x00;                //��Ʈ��
			s_steerWheel.Vel_x = fabs(s_pcCom.Vel_x)*100;
			s_steerWheel.Angle = 0;
			s_steerWheel.CtlMode = CONTROL_MODE_MANUAL;
			s_steerWheel.StateMode = RUN_MODE_ENABLE;
			sMove_manual_updata();
			break;
	
		case 0x01:
			s_steerWheel.MoveDir = 0x00;     //����
			s_steerWheel.TurnDir = 0x00;
			s_steerWheel.DirftOn = 0x00;                
			s_steerWheel.Vel_x = fabs(s_pcCom.Vel_x)*100;
			s_steerWheel.Angle = 0;
			s_steerWheel.CtlMode = CONTROL_MODE_MANUAL;
			s_steerWheel.StateMode = RUN_MODE_ENABLE;
			sMove_manual_updata();
			break;
	
		case 0x04:                             //��Ʈ��
			s_steerWheel.MoveDir = 0x01;
			s_steerWheel.DirftMode = 0x00;
			s_steerWheel.ForkMode = 0x01;               
			s_steerWheel.Vel_x = fabs(s_pcCom.Vel_x)*100;
			s_steerWheel.Angle = 9000;
			s_steerWheel.CtlMode = CONTROL_MODE_DIRFT;
			s_steerWheel.StateMode = RUN_MODE_ENABLE;
			sMove_dirft_updata();
			break;
	
		case 0x05:      
			s_steerWheel.MoveDir = 0x00;           //��Ʈ��
			s_steerWheel.DirftMode = 0x00;
			s_steerWheel.ForkMode = 0x01;                
			s_steerWheel.Vel_x = fabs(s_pcCom.Vel_x)*100;
			s_steerWheel.Angle = 9000;
			s_steerWheel.CtlMode = CONTROL_MODE_DIRFT;
			s_steerWheel.StateMode = RUN_MODE_ENABLE;
			sMove_dirft_updata();
			break;
	
		case 0x02:   			                        //��ת
			s_steerWheel.TurnDir = 0x01;			  
			s_steerWheel.TurnMode = 0x01;
			s_steerWheel.DirftOn = 0x00;                
			s_steerWheel.Vel_x = fabs(s_pcCom.Vel_x)*100;
			s_steerWheel.CtlMode = CONTROL_MODE_TURN;
			s_steerWheel.StateMode = RUN_MODE_ENABLE;
			sMove_turn_updata();
			break;
		
		case 0x03:   			                        //��ת
			s_steerWheel.TurnDir = 0x00;			
			s_steerWheel.TurnMode = 0x01;
			s_steerWheel.DirftOn = 0x00;               
			s_steerWheel.Vel_x = fabs(s_pcCom.Vel_x)*100;
			s_steerWheel.CtlMode = CONTROL_MODE_TURN;
			s_steerWheel.StateMode = RUN_MODE_ENABLE;
			sMove_turn_updata();
			break;
	}
}
/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
