/**
  ******************************************************************************
  * @file    app.h
  * @author  Zzl
  * @version V1.0.0
  * @date    2016-03-11
  * @brief   ���ļ���ģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ���������ơ�
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __APP_H
#define __APP_H

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
	 
/* Exported Types ------------------------------------------------------------*/
typedef struct
{
	u8    Enable;        //ʹ��
	u8    OutWayFlag;    //�ѹ��־
}App_T;

/* Exported Macro ------------------------------------------------------------*/
/* Exported Variables --------------------------------------------------------*/
/* Exported Function Prototypes ----------------------------------------------*/
void app_Init(void);
void app_Loop(void);
void taskMoveControl(void);
void taskLedControl(void);
void taskUpdataState(void);
void taskCheckSafe(void);
void check_nav_control(void);
void nav_control_forword(void);
void nav_control_back(void);
void nav_control_turn_left_90(void);
void nav_control_turn_right_90(void);
void nav_control_stop(void);
void nav_control_dirft_left(void);
void nav_control_dirft_right(void);
void nav_control_turn_round(void);
void check_panel_control(void);
void nav_front_station(void);
void nav_back_station(void);
#ifdef __cplusplus
}
#endif

#endif /* __APP_H */

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
