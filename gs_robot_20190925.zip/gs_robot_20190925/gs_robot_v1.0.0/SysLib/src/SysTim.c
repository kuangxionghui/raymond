/**
  ******************************************************************************
  * @file    sysTim.c
  * @author  Zzl
  * @version V1.0.0
  * @date    2016-03-10
  * @brief   ���ļ���ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ�������
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "sysTim.h"

/* Private Macro -------------------------------------------------------------*/
#define SYS_TIMER				      TIM3
#define SYS_TIMER_RCC 			  RCC_APB1Periph_TIM3
#define SYS_TIMER_IRQ			    TIM3_IRQn
#define SYS_TIMER_IRQHandler	TIM3_IRQHandler
#define SYS_TIMER_TICK		   	1.0f		//ms

/* Private Types -------------------------------------------------------------*/
typedef struct
{
	u32 Cnt;			//ʱ�����
	u32 Flag;			//�жϱ�־
	u8  NC[8];			//����
}SYS_TIM_T;

/* Exported Variables Defines-------------------------------------------------*/
/* Private Variables ---------------------------------------------------------*/
SYS_TIM_T	s_Tim;

/* Private Function Prototypes -----------------------------------------------*/
/* Function Defines ----------------------------------------------------------*/

/** @brief  		��ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sysTim_Init(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseInitStruct;	

	RCC_APB1PeriphClockCmd(SYS_TIMER_RCC, ENABLE);
	
	NVIC_InitStructure.NVIC_IRQChannel = SYS_TIMER_IRQ;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	TIM_DeInit(SYS_TIMER);
	TIM_TimeBaseInitStruct.TIM_Prescaler = 71;  //1M //ʱ�ӷ�Ƶ��
	TIM_TimeBaseInitStruct.TIM_Period = SYS_TIMER_TICK * 1000 - 1; //����
	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1; 
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(SYS_TIMER, &TIM_TimeBaseInitStruct);

	TIM_ClearFlag(SYS_TIMER, TIM_FLAG_Update);
	TIM_ITConfig(SYS_TIMER, TIM_IT_Update, ENABLE);
	TIM_Cmd(SYS_TIMER, ENABLE);
}

/** @brief  		�жϷ������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void SYS_TIMER_IRQHandler(void)
{
	if(TIM_GetITStatus(SYS_TIMER, TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(SYS_TIMER, TIM_FLAG_Update);
		s_Tim.Flag = 1;
		s_Tim.Cnt ++;
	}
}

/** @brief  		��ȡ��ǰʱ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��ǰʱ�� ��λS
  * @note			��
  */
float sysTim_GetTim(void)
{
	float s;
	u16 tim_cnt;

	tim_cnt = TIM_GetCounter(SYS_TIMER);
	s = ((float)s_Tim.Cnt * 1000 + tim_cnt) / 1000000;

	return s;
}

/** @brief  		��ȡ�жϱ�־
  * @param[in]  	��
  * @param[out]		��
  * @retval 		�жϱ�־
  * @note			��
  */
u8 sysTim_GetFlag(void)
{
	if(s_Tim.Flag)
	{
		s_Tim.Flag = 0;
		return 1;
	}
	
	return 0;
}

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
