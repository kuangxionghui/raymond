/**
  ******************************************************************************
  * @file    sysDelay.c
  * @author  Zzl
  * @version V1.0.0
  * @date    2016-03-10
  * @brief   ���ļ���DrvDelayģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ�������
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "sysDelay.h"

/* Private Macro -------------------------------------------------------------*/ 
/* Private Types -------------------------------------------------------------*/
/* Exported Variables Defines-------------------------------------------------*/
/* Private Variables ---------------------------------------------------------*/
/* Private Function Prototypes -----------------------------------------------*/
/* Function Defines ----------------------------------------------------------*/

/** @brief  		us��ʱ
  * @param[in]  	nus
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void delay_us(u32 nus)
{  
	u32 temp;  
	SysTick->LOAD = 9 * nus;  
	SysTick->VAL  = 0X00;
	SysTick->CTRL = 0X01; 
	do  
	{   
		temp = SysTick->CTRL;
	}while((temp & 0x01) && (! (temp & (1 << 16))));
	SysTick->CTRL = 0x00; 
	SysTick->VAL  = 0X00; 
} 

/** @brief  		ms��ʱ
  * @param[in]  	nms
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void delay_ms(u16 nms) 
{  
	u32 temp; 
	SysTick->LOAD = 9000 * nms;  
	SysTick->VAL  = 0X00;
	SysTick->CTRL = 0X01;
	do  
	{   
		temp=SysTick->CTRL;
	}while((temp & 0x01)&&(! (temp & (1 << 16))));
	SysTick->CTRL =0x00;
	SysTick->VAL  =0X00;
}
/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
