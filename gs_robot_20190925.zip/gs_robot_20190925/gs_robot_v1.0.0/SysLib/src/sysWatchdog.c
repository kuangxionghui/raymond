/**
  ******************************************************************************
  * @file    sysWatchdog.c
  * @author  Zzl
  * @version V1.0.0
  * @date    2015-06-10
  * @brief   ���ļ���ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ�������
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "sysWatchdog.h"

/* Private Macro -------------------------------------------------------------*/ 
/* Private Types -------------------------------------------------------------*/
/* Exported Variables Defines-------------------------------------------------*/
/* Private Variables ---------------------------------------------------------*/
/* Private Function Prototypes -----------------------------------------------*/
/* Function Defines ----------------------------------------------------------*/

/** @brief  		Watchdog��ʼ��
  * @param[in]  	pre	: ��Ƶ
					cnt : ����ֵ
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sysWatchdog_Init(u8 pre, u16 cnt)
{
	RCC_LSICmd(ENABLE);
	/* Wait till LSI is ready */
	while (RCC_GetFlagStatus(RCC_FLAG_LSIRDY) == RESET){}
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
	IWDG_SetPrescaler(pre);
	IWDG_SetReload(cnt);  
	IWDG_ReloadCounter();
	IWDG_Enable();		
}

/** @brief  		ι��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sysWatchdog_ReloadCounter(void)
{
	IWDG_ReloadCounter();
}

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/

