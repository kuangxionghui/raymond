/**
  ******************************************************************************
  * @file    sys.c
  * @author  Zzl
  * @version V1.0.0
  * @date    2016-03-10
  * @brief   ���ļ���sysģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ�������
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "sys.h"

/* Private Macro -------------------------------------------------------------*/ 
/* Private Types -------------------------------------------------------------*/
/* Exported Variables Defines-------------------------------------------------*/
/* Private Variables ---------------------------------------------------------*/
/* Private Function Prototypes -----------------------------------------------*/
/* Function Defines ----------------------------------------------------------*/

/** @brief  		ϵͳʱ�ӳ�ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sSys_RCCInit(void)
{
	ErrorStatus HSEStartUpStatus;
	
	RCC_DeInit(); 
	RCC_HSEConfig(RCC_HSE_ON);
	HSEStartUpStatus = RCC_WaitForHSEStartUp();
	if(HSEStartUpStatus == SUCCESS)
	{
		RCC_HCLKConfig(RCC_SYSCLK_Div1);   //HCLK = 72M
		RCC_PCLK2Config(RCC_HCLK_Div1);		//APB2 = 72M
		RCC_PCLK1Config(RCC_HCLK_Div2);		//APB1 = 36M

		SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);  //9M
		
		FLASH_SetLatency(FLASH_Latency_2);
		FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

		RCC_PLLConfig(RCC_PLLSource_HSE_Div1,RCC_PLLMul_9);
		
		RCC_ADCCLKConfig(RCC_PCLK2_Div6);  //ADC = 12M  
		
		RCC_PLLCmd(ENABLE);
		while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET);

		RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
		while(RCC_GetSYSCLKSource() != 0X08);
	}
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
}

/** @brief  		ϵͳ��ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sys_Init(void)
{
	sSys_RCCInit();
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	sysTim_Init();
	sysRst_Init();
}

/** @brief  		ѭ������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sys_Loop(void)
{
	sysRst_Loop();
}

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
