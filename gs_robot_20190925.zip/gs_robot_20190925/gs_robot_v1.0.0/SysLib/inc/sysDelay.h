/**
  ******************************************************************************
  * @file    sysDelay.h
  * @author  Zzl
  * @version V1.0.0
  * @date    2016-03-10
  * @brief   ���ļ���Delayģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ���������ơ�
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __SYS_DELAY_H
#define __SYS_DELAY_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"

/* Exported Macro ------------------------------------------------------------*/

/* Exported Types ------------------------------------------------------------*/

/* Exported Variables --------------------------------------------------------*/

/* Exported Function Prototypes ----------------------------------------------*/
void delay_us(u32 nus);
void delay_ms(u16 nms);

#ifdef __cplusplus
}
#endif

#endif /* __SYS_DELAY_H */ 

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
