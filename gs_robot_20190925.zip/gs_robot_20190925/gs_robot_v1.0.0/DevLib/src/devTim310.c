/**
  ******************************************************************************
  * @file    devTim310.c
  * @author  kuang
  * @version V1.0.0
  * @date    2019-06-17
  * @brief   ���ļ���ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "devTim310.h"
#include "bspGPIO.h"
#include "bsp.h"
#include "devPcCommunication.h"
/* Private Macro -------------------------------------------------------------*/

/* Private Types -------------------------------------------------------------*/

extern GPIO_T s_GPIO;
extern PcCom_T s_pcCom;
Tim310 s_tim310;

/** @brief  		ģ���ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devTIM310_Init(void)
{
	s_tim310.FrontEnable = 1;
	s_tim310.BackEnable = 1;
	//s_tim310.LeftEnable = 1;
	//s_tim310.RightEnable = 1;
	s_tim310.BackValue = 0;
	s_tim310.FrontValue = 0;
	//s_tim310.LeftValue = 0;
	///s_tim310.RightValue = 0;
	s_tim310.Obstacle = 0;
	s_tim310.BackSlowlyValue = 0x07;
	s_tim310.BackStopValue = 0x03;
	s_tim310.FrontSlowlyValue = 0x70;
	s_tim310.FrontStopValue = 0x30;
	bspGPIO_SetY(Y00,0);
	bspGPIO_SetY(Y01,0);
	bspGPIO_SetY(Y02,0);
	bspGPIO_SetY(Y03,1);
	
	bspGPIO_SetY(Y04,0);
	bspGPIO_SetY(Y05,0);
	bspGPIO_SetY(Y06,0);
	bspGPIO_SetY(Y07,1);
	
}

/** @brief  		ѭ������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devTim310_Loop(void)
{	
	//ʹ��
	
	s_tim310.BackValue = checkTim310Back();
	s_tim310.FrontValue = checkTim310Front();
	//s_tim310.LeftValue = checkWrLeft();
	//s_tim310.RightValue = checkWrRight();
  
	if(s_pcCom.GetGoods == 1)         //���ֿ��ʱ��ر�ǰ��ı���
	{
		s_tim310.FrontStopValue = 0x10;
		s_tim310.BackStopValue = 0x01;
	}
	else
	{
		s_tim310.FrontStopValue = 0x30; //���ֿ��
	  s_tim310.BackStopValue = 0x03;
	}
	/*
	if(s_pcCom.PickUp == 1)     //��խ����򿪲�����״�
	{
		s_tim310.LeftEnable = 1;
		s_tim310.RightEnable = 1;
	}
	else                        //��խ����رղ�����״�
	{
		s_tim310.LeftEnable = 0;
		s_tim310.RightEnable = 0;
	}
	*/
}

/** @brief  		����ǰ��tim310
  * @param[in]  	��
  * @param[out]		f_t_value
  * @retval 		��
  * @note			��
  */
u8 checkTim310Front(void)
{
	static u8 f_t_value = 0xFF;
	
	f_t_value = ((s_GPIO.X[0] & 0xF0));
	return f_t_value;
}

/** @brief  		���Һ���tim310
  * @param[in]  	��
  * @param[out]		b_t_value
  * @retval 		��
  * @note			��
  */
u8 checkTim310Back(void)
{
	static u8 b_t_value = 0xFF;
	
	b_t_value = s_GPIO.X[0] & 0x0F;
	return b_t_value;
}

/** @brief  		���Ҳ�����״�
  * @param[in]  	��
  * @param[out]		b_t_value
  * @retval 		��
  * @note			��
  */
u8 checkWrLeft(void)
{
	static u8 b_t_value = 0xFF;
	
	b_t_value = s_GPIO.X[1] & 0x04;
	return b_t_value;
}

/** @brief  		���Ҳ�����״�
  * @param[in]  	��
  * @param[out]		b_t_value
  * @retval 		��
  * @note			��
  */
u8 checkWrRight(void)
{
	static u8 b_t_value = 0xFF;
	
	b_t_value = s_GPIO.X[1] & 0x02;
	return b_t_value;
}

/************* (C) COPYRIGHT 2019 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
