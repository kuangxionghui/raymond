/**
  ******************************************************************************
  * @file    devAntiBar.c
  * @author  kuang
  * @version V1.0.0
  * @date    2019-06-17
  * @brief   ���ļ��Ƿ�ײ��ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "devAntiBar.h"
#include "bspGPIO.h"
#include "bsp.h"
#include "sys.h"

/* Private Macro -------------------------------------------------------------*/

/* Private Types -------------------------------------------------------------*/
AntiBar s_antiBar;
extern GPIO_T s_GPIO;
/** @brief  		ģ���ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devAntiBar_Init(void)
{
	s_antiBar.Enable = 1;
	s_antiBar.count = 0;
	s_antiBar.flag = 0;
	s_antiBar.Value = 0;
}

/** @brief  		ѭ������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devAntiBar_Loop(void)
{	
	if(s_antiBar.Enable == 0)
		return;
	
	s_antiBar.Value = s_GPIO.X[1] & 0x01;
	if(s_antiBar.Value == 0x01)
	{
		s_antiBar.count++;
		if(s_antiBar.count >= 3)   //100ms�����ֹ����
		{
			s_antiBar.count = 0;
			s_antiBar.flag = 1;
		}
	}
	else
	{
		s_antiBar.count = 0;
		//s_antiBar.flag = 0;
	}
}


/************* (C) COPYRIGHT 2019 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
