/**
  ******************************************************************************
  * @file    devRemoteControl.c
  * @author  kuang
  * @version V1.0.0
  * @date    2019-06-17
  * @brief   ���ļ���ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "devRemoteControl.h"
#include "bsp.h"
#include "stdVerify.h"
#include "devStaBus.h"
#include "devSteeringWheel.h"
#include "stdMath.h"
#include <math.h>
#include "devCardReader.h"
#include <string.h>
#include "devCardReader.h"
#include "devTim310.h"
/* Private Macro -------------------------------------------------------------*/
#define STABUS_RXCHECKBIT	  0X0001	//���ռ��λ

/* Private Types -------------------------------------------------------------*/
RemoteCtl_T s_remoteCtl;

extern SteerWheel_T s_steerWheel;
extern ReadCard_T s_readCard;
extern Tim310 s_tim310;
/* ---------------------------------------------------------------------------*/


/** @brief  		ģ���ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devRemoteControl_Init(void)
{
	memset(&s_remoteCtl,0,sizeof(s_remoteCtl));
	s_remoteCtl.Enable = 1;
	s_remoteCtl.ErrorFlag = 0;
	s_remoteCtl.LinkFlag = 0;
	s_remoteCtl.ModeRf = MODE_OUTLINE;    //Ĭ���ֶ�ģʽ
	s_remoteCtl.ButtonValue = 0;
	s_remoteCtl.Spin = 0;
	s_remoteCtl.Vel_x = 0;
	s_remoteCtl.Vel_y = 0;
	s_remoteCtl.Vel_w = 0;
}

/** @brief  		ң��ģ��ѭ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devRemoteControl_Loop(void)
{
		//ʹ��
	if(s_remoteCtl.Enable == 0)
		return;
	
	if(s_remoteCtl.ErrorFlag == 1)
		return;
	
}

/** @brief  		����ģʽ
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void check_outline_control(void)
{	
	//
	if(s_remoteCtl.ModeRf == 0x00)
	{
		//��鰴������
		switch(s_remoteCtl.ButtonValue)
		{
			//û�а���
			case BUTTON_NOTHING:
				s_steerWheel.Vel_x = 0;
				s_steerWheel.Angle = 0;
				s_steerWheel.CtlMode = CONTROL_MODE_MANUAL;
				s_steerWheel.StateMode = RUN_MODE_BRAKE;    //ɲ��
				sMove_manual_updata();
				break;
		
			//��ͷ��
			case BUTTON_FORWORD:
				s_steerWheel.MoveDir = 0x01;     //ǰ��
				s_steerWheel.TurnDir = 0x00;
				s_steerWheel.DirftOn = 0x00;                //��Ʈ��
				s_steerWheel.Vel_x = fabs(s_remoteCtl.Vel_x)*100;
				s_steerWheel.Angle = 0;
				s_steerWheel.CtlMode = CONTROL_MODE_MANUAL;
				s_steerWheel.StateMode = RUN_MODE_ENABLE;
				sMove_manual_updata();
				break;
		
			//��ͷ��
			case BUTTON_BACK:
				s_steerWheel.MoveDir = 0x00;     //����
				s_steerWheel.TurnDir = 0x00;
				s_steerWheel.DirftOn = 0x00;                //��Ʈ��
				s_steerWheel.Vel_x = fabs(s_remoteCtl.Vel_x)*100;
				s_steerWheel.Angle = 0;
				s_steerWheel.CtlMode = CONTROL_MODE_MANUAL;
				s_steerWheel.StateMode = RUN_MODE_ENABLE;
				sMove_manual_updata();
				break;
		
			//��ͷ��
			case BUTTON_DIRFT_LEFT:      
				s_steerWheel.MoveDir = 0x01;
				s_steerWheel.DirftMode = 0x00;
				s_steerWheel.ForkMode = 0x00;                //Ʈ��
				s_steerWheel.Vel_x = fabs(s_remoteCtl.Vel_y)*100;
				s_steerWheel.Angle = 9000;
				s_steerWheel.CtlMode = CONTROL_MODE_DIRFT;
				s_steerWheel.StateMode = RUN_MODE_ENABLE;
				sMove_dirft_updata();
				break;
		
			//��ͷ��
			case BUTTON_DIRFT_RIGHT:      
				s_steerWheel.MoveDir = 0x00;
				s_steerWheel.DirftMode = 0x00;
				s_steerWheel.ForkMode = 0x00;                //Ʈ��
				s_steerWheel.Vel_x = fabs(s_remoteCtl.Vel_y)*100;
				s_steerWheel.Angle = 9000;
				s_steerWheel.CtlMode = CONTROL_MODE_DIRFT;
				s_steerWheel.StateMode = RUN_MODE_ENABLE;
				sMove_dirft_updata();
				break;
		
			//��ת����
			case BUTTON_TURN:   
				if(s_remoteCtl.Spin == -1)
				{			
					s_steerWheel.TurnDir = 0x00;
				}				
				else if(s_remoteCtl.Spin == 1)
				{		
					s_steerWheel.TurnDir = 0x01;
				}
				s_steerWheel.TurnMode = 0x00;
				s_steerWheel.DirftOn = 0x00;                //��Ʈ��
				s_steerWheel.Vel_x = fabs(s_remoteCtl.Vel_w)*100;
				s_steerWheel.CtlMode = CONTROL_MODE_TURN;
				s_steerWheel.StateMode = RUN_MODE_ENABLE;
				sMove_turn_updata();
				break;
		}
  }
	if(s_remoteCtl.ModeRf == 0x02)
	{
		check_fun_control();
	}

}

/** @brief  		����ģʽ
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void check_fun_control(void)
{
	switch(s_remoteCtl.ButtonValue)
	{
		case BUTTON_TURN:
			s_remoteCtl.FindCard = 0;    //ֹͣ�ҿ�        
			break;
		case BUTTON_FORWORD:
			s_remoteCtl.FindCard = 1;   //��ǰ�ҿ�
			break;
		case BUTTON_BACK:
			s_remoteCtl.FindCard = 2;   //����ҿ�
		  break;
		case BUTTON_DIRFT_LEFT:       //�������
			s_remoteCtl.FindCard = 3;
			break;
		case BUTTON_DIRFT_RIGHT:
			s_remoteCtl.FindCard = 4;   //���Ҳ���
			break;
	}
	fun_button_process();
}

/** @brief  		�������ܰ�������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void fun_button_process(void)
{
	switch(s_remoteCtl.FindCard)
	{
		case 0:
			//s_steerWheel.CtlMode = CONTROL_MODE_MANUAL;
			s_steerWheel.StateMode = RUN_MODE_ENABLE;
			s_steerWheel.ForkMode = 0x00;
		  s_steerWheel.Vel_x = 0;
			sMove_manual_updata();
			break;
		
		case 1:
			s_steerWheel.Vel_x = 3*100;
			//���ϼ��
			if((s_tim310.FrontEnable == 1) && (s_tim310.FrontValue <= s_tim310.FrontStopValue))
			{
				s_steerWheel.Vel_x = 0;
			}
			s_steerWheel.CtlMode = CONTROL_MODE_NAV;
			s_steerWheel.StateMode = RUN_MODE_ENABLE;
			s_steerWheel.MoveDir = 0x01;	  //ǰ��
			s_steerWheel.ForkMode = 0x00;
			sMove_nav_updata();
			if(s_readCard.GetNewCard == 1)
			{
				s_readCard.GetNewCard = 0;
				s_steerWheel.Vel_x = 0;
				s_remoteCtl.FindCard = 0;
				sMove_nav_updata();
			}
			break;
		
		case 2:
			s_steerWheel.Vel_x = 3*100;
			//���ϼ��
			if((s_tim310.BackEnable == 1) && (s_tim310.BackValue <= s_tim310.BackStopValue))
			{
				s_steerWheel.Vel_x = 0;
			}
			s_steerWheel.CtlMode = CONTROL_MODE_NAV;
			s_steerWheel.StateMode = RUN_MODE_ENABLE;
			s_steerWheel.MoveDir = 0x00;	  //����
			s_steerWheel.ForkMode = 0x00;
			sMove_nav_updata();
			if(s_readCard.GetNewCard == 1)
			{
				s_readCard.GetNewCard = 0;
				s_steerWheel.Vel_x = 0;
				s_remoteCtl.FindCard = 0;
				sMove_nav_updata();
			}
			break;
			
		case 3:
			s_steerWheel.CtlMode = CONTROL_MODE_DIRFT;
			s_steerWheel.StateMode = RUN_MODE_ENABLE;
			s_steerWheel.MoveDir = 0x01;
			s_steerWheel.DirftMode = 0x02;              //�ŵ�������ģʽ
			s_steerWheel.ForkMode = 0x00;               //Ʈ��
			s_steerWheel.Angle = 9000;
		  s_steerWheel.Vel_x = 3*100;
			sMove_dirft_updata();
		  if(s_readCard.GetNewCard == 1)
			{
				s_readCard.GetNewCard = 0;
				s_steerWheel.Vel_x = 0;
				s_remoteCtl.FindCard = 0;
				sMove_dirft_updata();
			}
			break;
			
		case 4:
			s_steerWheel.CtlMode = CONTROL_MODE_DIRFT;
			s_steerWheel.StateMode = RUN_MODE_ENABLE;
			s_steerWheel.MoveDir = 0x00;
			s_steerWheel.DirftMode = 0x02;              //�ŵ�������ģʽ
			s_steerWheel.ForkMode = 0x00;               //Ʈ��
			s_steerWheel.Angle = 9000;
		  s_steerWheel.Vel_x = 3*100;
			sMove_dirft_updata();
		  if(s_readCard.GetNewCard == 1)
			{
				s_readCard.GetNewCard = 0;
				s_steerWheel.Vel_x = 0;
				s_remoteCtl.FindCard = 0;
				sMove_dirft_updata();
			}
			break;
	}
}

/** @brief  		��������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devRemoteControl_RxData(u8 buf[], u16 len)
{
	u8 offset;
  
	s_remoteCtl.ErrorFlag = 1;
	
	if(s_remoteCtl.Enable == 0)
		return;
	
	if(len != 37)
		return;
  
	if((buf[0] != 0xF1)&&(buf[36] != 0xF3))
		return;
	
	offset = 3;
  s_remoteCtl.ErrorFlag = 0;
	s_remoteCtl.LinkFlag = buf[offset+1];
	s_remoteCtl.ModeRf = buf[offset+8];
	s_remoteCtl.Spin = buf[offset+9];
	s_remoteCtl.Vel_x = ((buf[offset+19] & 0x00FF)<<8) + buf[offset+18];
	s_remoteCtl.Vel_y = ((buf[offset+21] & 0x00FF)<<8) + buf[offset+20];
	s_remoteCtl.Vel_w = ((buf[offset+23] & 0x00FF)<<8) + buf[offset+22];
	s_remoteCtl.ButtonValue = ((buf[offset+25] & 0x00FF)<<8) + buf[offset+24];
}

/** @brief  		����
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devRemoteControl_TxData(u8 buf[], u16 *len)
{
	//ʹ��
	if(s_remoteCtl.Enable == 0)
	{
		*len = 0;
		return;
	}
	
	//���
	buf[0] = REMOTO_HEAD_CODE;
	buf[1] = REMOTE_ID;
	buf[2] = REMOTO_FUN_CODE;
	buf[3] = 0;
	buf[4] = stdVerify_Xor(buf, 0, 4);
	buf[5] = REMOTO_END_CODE;
	*len = 6;
}

/************* (C) COPYRIGHT 2019 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
