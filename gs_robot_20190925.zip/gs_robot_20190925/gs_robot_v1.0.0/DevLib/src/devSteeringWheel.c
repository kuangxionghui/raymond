/**
  ******************************************************************************
  * @file    devSteeringWheel.c
  * @author  kuang
  * @version V1.0.0
  * @date    2019-06-17
  * @brief   ���ļ���ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "devSteeringWheel.h"
#include "bsp.h"
#include "devRemoteControl.h"
#include <string.h>
#include <math.h>
#include "devAntiBar.h"
#include "devPcCommunication.h"
#include <stdio.h>
#include "devEmergencyButton.h"
/* Private Macro -------------------------------------------------------------*/

#define JUNCTION_MODE_STRAIGHT  0x00  //��·ֱ��
#define JUNCTION_MODE_LEFT  0x01    //��·�������
#define JUNCTION_MODE_RIGHT  0x02   //��·�ұ�����

#define RUN_DIR_FORWORD     0x00    //ǰ��
#define RUN_DIR_BACK        0x01    //����

#define RUN_DIR_LEFT        0x00    //����
#define RUN_DIR_RIGHT       0x01    //����

#define DIRFT_DISABLE       0x00    //��Ư��
#define DIRFT_ENABLE       0x01    //Ư��

#define STABUS_RXCHECKBIT	  0X0001	//���ռ��λ
/* Private Types -------------------------------------------------------------*/
SteerWheel_T s_steerWheel;
extern RemoteCtl_T s_remoteCtl;
extern AntiBar s_antiBar;
extern PcCom_T s_pcCom;
extern Emergency_T s_emergency;
u8 tx_cmd[18];

/** @brief  		CRCУ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
unsigned int CRC_Verify(unsigned char *cBuffer, unsigned int iBufLen)
{
  unsigned int i, j; //#define wPolynom 0xA001
  unsigned int wCrc = 0xffff;
  unsigned int wPolynom = 0xA001;
  /*---------------------------------------------------------------------------------*/
  for (i = 0; i < iBufLen; i++)
  {
    wCrc ^= cBuffer[i];
    for (j = 0; j < 8; j++)
    {
      if (wCrc &0x0001)
      { 
			  wCrc = (wCrc >> 1) ^ wPolynom; 
			}
      else
      { 
			  wCrc = wCrc >> 1; 
			}
    }  
	}
  return wCrc;
}

/** @brief  		ģ���ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devSteeringWheel_Init(void)
{
	memset(&s_steerWheel,0,sizeof(s_steerWheel));
	s_steerWheel.Enable = 1;
	s_steerWheel.AckMode = 0x06;
	s_steerWheel.CleanMode = 0x00;
	s_steerWheel.IoMode = 0x00;
	s_steerWheel.DirftOn = 0x00;                //��Ʈ��
	s_steerWheel.ResetFlag = 1;                 //��λ
}

/** @brief  		ģ��ѭ�� 
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devSteeringWheel_Loop(void)
{
	if(s_steerWheel.Enable == 0)
		return;
	
	devSteeringWheel_Reset();
	devSteeringWheel_TxData();
	devSteeringWheel_RxData();
}

/** @brief  		��λ��ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devSteeringWheel_Reset(void)
{
	static u16 init_delay_cnt = 0;
	
	if(s_steerWheel.InitCmpFlag == 0)
	{
		s_steerWheel.Vel_x = 0;
		s_steerWheel.CtlMode = CONTROL_MODE_DIRFT;
		s_steerWheel.StateMode = RUN_MODE_ENABLE;
		s_steerWheel.MoveDir = 0x01;
		s_steerWheel.DirftMode = 0x02;              //�ŵ�������ģʽ
		s_steerWheel.ForkMode = 0x00;               //Ʈ��
		s_steerWheel.Angle = 9000;
		sMove_dirft_updata();
		
		init_delay_cnt++;
		if(init_delay_cnt >= 150)
		{
			init_delay_cnt = 150;
			s_steerWheel.InitCmpFlag = 1; 
		}
	}
}

void check_ack_mode(void)
{
	static u16 check_steering_cnt = 0;
	static u8 ack_state = 0;
	
	switch(ack_state)
	{
		case 0:
			s_steerWheel.AckMode = 0x06;
			check_steering_cnt++;
		  if(check_steering_cnt > 8)
			{
				check_steering_cnt = 0;
				ack_state = 1;
			}
			break;
			
		case 1:
			s_steerWheel.AckMode = 0x07;
		  check_steering_cnt++;
		  if(check_steering_cnt > 1)
			{
				check_steering_cnt = 0;
				ack_state = 2;
			}
			break;
			
		case 2:
			s_steerWheel.AckMode = 0x03;
		  check_steering_cnt++;
		  if(check_steering_cnt > 1)
			{
				check_steering_cnt = 0;
				ack_state = 0;
			}
			break;
	}
	
  
}

/** @brief  		��������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */

void devSteeringWheel_TxData(void)
{
	u16 len;
	
	u16 i;
	u16 check_sum;
	
	check_ack_mode();
	
	len = 18;
	for(i=0;i<len-2;i++)
  {
		tx_cmd[i] = s_steerWheel.SendCmd[i];
	}
	tx_cmd[0] = SW_HEAD_CODE;
	tx_cmd[1] = SW_MFIO;
	if(s_steerWheel.ResetFlag == 1)
	{
		s_steerWheel.ResetFlag = 0;
		tx_cmd[3] = 0x01; 
	}
	else
	{
		tx_cmd[3] = 0x00; 
	}
	if((s_antiBar.flag == 1)||(s_pcCom.PcAlarmFlag == 1)||(s_pcCom.TimeOutFlag == 1)||(s_pcCom.PauseFlag == 1)||(s_emergency.flag == 1))
	{
		tx_cmd[7] = 0x03; 
	}
	tx_cmd[15] = SW_END_CODE;
	check_sum = CRC_Verify(tx_cmd, len-2);
	tx_cmd[16] = (u8)(check_sum & 0x00FF);
	tx_cmd[17] = (u8)((check_sum & 0xFF00)>>8);
	bspUsart_PutStr(SERIAL_PORT2,tx_cmd,len);
}

/** @brief  		ģ��ѭ�� 
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devSteeringWheel_RxData(void)
{
	u8* buf;
	u16 len;
	
	//����
	if(bspUsart_GetStr(SERIAL_PORT2, STABUS_RXCHECKBIT, &buf, &len))
		return;

	//��ǰͨ���豸
  checkSteeringWheel_RxData(buf, len);
}

/** @brief  		 ��������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void checkSteeringWheel_RxData(u8 buf[], u16 len)
{	
	u8 i;
	u8 ecode_h;
	u8 ecode_l;
  static u16 CurrentEncodeCnt = 0;
	static u16 LastEncodeCnt = 0;
	static u16 NewEncodeCnt = 0;
	//if(len != 18)
	//	return;
	
	//if((buf[0] != 0x55) || (buf[1] != 0x01) ||(buf[2] != 0x06))  //head
	//	return;
	
	for(i=0;i<18;i++)
	{
		s_steerWheel.RecvBuf[i] = buf[i];
	}
	
	if(s_steerWheel.RecvBuf[2] == 0x06)
	{
		s_steerWheel.SensorFlag_f = s_steerWheel.RecvBuf[7];          //���ŵ����Ƿ�����
		s_steerWheel.SensorOffset_f = fabs(s_steerWheel.RecvBuf[8]);  //ƫ����
		s_steerWheel.SensorFlag_l = s_steerWheel.RecvBuf[11];          //���ŵ����Ƿ�����
		s_steerWheel.SensorOffset_l = fabs(s_steerWheel.RecvBuf[12]);  //ƫ����
		s_steerWheel.SensorFlag_r = s_steerWheel.RecvBuf[13];          //���ŵ����Ƿ�����
		s_steerWheel.SensorOffset_r = fabs(s_steerWheel.RecvBuf[14]);  //ƫ����
	}
	else if(s_steerWheel.RecvBuf[2] == 0x07)
	{
		s_steerWheel.MFIOError = s_steerWheel.RecvBuf[3];
		s_steerWheel.FrontError = s_steerWheel.RecvBuf[4];
		s_steerWheel.BackError = s_steerWheel.RecvBuf[5];
		if((s_steerWheel.MFIOError == 0) && (s_steerWheel.FrontError == 0) && (s_steerWheel.BackError == 0))
		{
			s_steerWheel.ErrorFlag = 0;
		}
		else
		{
			s_steerWheel.ErrorFlag = 1;
		}
		s_steerWheel.RunMode = s_steerWheel.RecvBuf[6];
	}
	else if(s_steerWheel.RecvBuf[2] == 0x03)
	{
		ecode_h = fabs(s_steerWheel.RecvBuf[3]);
		ecode_l = fabs(s_steerWheel.RecvBuf[4]);
		CurrentEncodeCnt = ecode_h;
		CurrentEncodeCnt = (CurrentEncodeCnt << 8)&0xFF00;
		CurrentEncodeCnt = CurrentEncodeCnt | ecode_l;
		CurrentEncodeCnt = CurrentEncodeCnt;
		NewEncodeCnt = fabs(CurrentEncodeCnt - LastEncodeCnt);
		if(NewEncodeCnt > 5)
		{
			LastEncodeCnt = CurrentEncodeCnt;
			s_steerWheel.EncodeCnt_1++;
		}
		
		/*
		if(s_steerWheel.EncodeCnt_1 > 5000)
		{
			s_steerWheel.EncodeCnt++;
		}
		*/
	}
}

/** @brief  		�������ò���
  * @param[in]  	                   
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sMove_nav_updata(void)
{
	if(s_steerWheel.Enable == 0)
		return;
		
	s_steerWheel.SendCmd[0] = SW_HEAD_CODE;
	s_steerWheel.SendCmd[1] = SW_MFIO;
	s_steerWheel.SendCmd[2] = s_steerWheel.AckMode;
	s_steerWheel.SendCmd[3] = s_steerWheel.CleanMode;
	s_steerWheel.SendCmd[4] = s_steerWheel.IoMode;
	s_steerWheel.SendCmd[5] = SW_RETAIN;
	s_steerWheel.SendCmd[6] = s_steerWheel.CtlMode;     
	s_steerWheel.SendCmd[7] = s_steerWheel.StateMode;             
	s_steerWheel.SendCmd[8] = s_steerWheel.MoveDir;
	s_steerWheel.SendCmd[9] = s_steerWheel.ForkMode;
	s_steerWheel.SendCmd[10] = SW_RETAIN;
	s_steerWheel.SendCmd[11] = (u8)((s_steerWheel.Vel_x & 0xFF00)>>8);
	s_steerWheel.SendCmd[12] = (u8)(s_steerWheel.Vel_x & 0x00FF);
	s_steerWheel.SendCmd[13] = SW_RETAIN;
	s_steerWheel.SendCmd[14] = SW_RETAIN;
	s_steerWheel.SendCmd[15] = SW_END_CODE;
}

/** @brief  		   �ֶ����ò���
  * @param[in]  	 run_mode: ����ģʽ
                   agv_dir��agv����
                   dirft_able: Ư��ʹ��
                   turn_dir����ת����
                   speed: �ٶ�
                   angle: �Ƕ�
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sMove_manual_updata(void)
{
	if(s_steerWheel.Enable == 0)
		return;
	
	s_steerWheel.SendCmd[0] = SW_HEAD_CODE;
	s_steerWheel.SendCmd[1] = SW_MFIO;
	s_steerWheel.SendCmd[2] = s_steerWheel.AckMode;
	s_steerWheel.SendCmd[3] = s_steerWheel.CleanMode;
	s_steerWheel.SendCmd[4] = s_steerWheel.IoMode;
	s_steerWheel.SendCmd[5] = SW_RETAIN;
	s_steerWheel.SendCmd[6] = s_steerWheel.CtlMode;     
	s_steerWheel.SendCmd[7] = s_steerWheel.StateMode;             
	s_steerWheel.SendCmd[8] = s_steerWheel.MoveDir;
	s_steerWheel.SendCmd[9] = s_steerWheel.DirftOn;
	s_steerWheel.SendCmd[10] = s_steerWheel.TurnDir;
	s_steerWheel.SendCmd[11] = (u8)((s_steerWheel.Vel_x & 0xFF00)>>8);
	s_steerWheel.SendCmd[12] = (u8)(s_steerWheel.Vel_x & 0x00FF);
	s_steerWheel.SendCmd[13] = (u8)((s_steerWheel.Angle & 0xFF00)>>8);
	s_steerWheel.SendCmd[14] = (u8)(s_steerWheel.Angle & 0x00FF);
	s_steerWheel.SendCmd[15] = SW_END_CODE;
}

/** @brief  		   Ư�����ò���
  * @param[in]  	 run_mode: ����ģʽ
                   dirft_dir������
                   dirft_mode: Ư��ģʽ
                   junction_dir����·�ڷ���
                   speed: �ٶ�
                   angle: �Ƕ�
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sMove_dirft_updata(void)
{
	if(s_steerWheel.Enable == 0)
		return;
	
	s_steerWheel.SendCmd[0] = SW_HEAD_CODE;
	s_steerWheel.SendCmd[1] = SW_MFIO;
	s_steerWheel.SendCmd[2] = s_steerWheel.AckMode;
	s_steerWheel.SendCmd[3] = s_steerWheel.CleanMode;
	s_steerWheel.SendCmd[4] = s_steerWheel.IoMode;
	s_steerWheel.SendCmd[5] = SW_RETAIN;
	s_steerWheel.SendCmd[6] = s_steerWheel.CtlMode;     
	s_steerWheel.SendCmd[7] = s_steerWheel.StateMode;             
	s_steerWheel.SendCmd[8] = s_steerWheel.MoveDir;
	s_steerWheel.SendCmd[9] = s_steerWheel.DirftMode;
	s_steerWheel.SendCmd[10] = s_steerWheel.ForkMode;
	s_steerWheel.SendCmd[11] = (u8)((s_steerWheel.Vel_x & 0xFF00)>>8);
	s_steerWheel.SendCmd[12] = (u8)(s_steerWheel.Vel_x & 0x00FF);
	s_steerWheel.SendCmd[13] = (u8)((s_steerWheel.Angle & 0xFF00)>>8);
	s_steerWheel.SendCmd[14] = (u8)(s_steerWheel.Angle & 0x00FF);
	s_steerWheel.SendCmd[15] = SW_END_CODE;
}

/** @brief  		   ��ת���ò���
  * @param[in]  	 run_mode: ����ģʽ
                   turn_dir������
                   turn_mode: ����
                   speed: �ٶ�
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sMove_turn_updata(void)
{
	if(s_steerWheel.Enable == 0)
		return;

	s_steerWheel.SendCmd[0] = SW_HEAD_CODE;
	s_steerWheel.SendCmd[1] = SW_MFIO;
	s_steerWheel.SendCmd[2] = s_steerWheel.AckMode;
	s_steerWheel.SendCmd[3] = s_steerWheel.CleanMode;
	s_steerWheel.SendCmd[4] = s_steerWheel.IoMode;
	s_steerWheel.SendCmd[5] = SW_RETAIN;
	s_steerWheel.SendCmd[6] = s_steerWheel.CtlMode;     
	s_steerWheel.SendCmd[7] = s_steerWheel.StateMode;             
	s_steerWheel.SendCmd[8] = s_steerWheel.TurnDir;
	s_steerWheel.SendCmd[9] = s_steerWheel.TurnMode;
	s_steerWheel.SendCmd[10] = SW_RETAIN;
	s_steerWheel.SendCmd[11] = (u8)((s_steerWheel.Vel_x & 0xFF00)>>8);;
	s_steerWheel.SendCmd[12] = (u8)(s_steerWheel.Vel_x & 0x00FF);
	s_steerWheel.SendCmd[13] = SW_RETAIN;
	s_steerWheel.SendCmd[14] = SW_RETAIN;
	s_steerWheel.SendCmd[15] = SW_END_CODE;
}

/************* (C) COPYRIGHT 2019 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
