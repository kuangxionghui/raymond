/**
  ******************************************************************************
  * @file    dev.c
  * @author  Zzl
  * @version V1.0.0
  * @date    2017-11-25
  * @brief   ���ļ���ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ�������
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "dev.h"
#include "bsp.h"

/* Private Macro -------------------------------------------------------------*/ 


/* Private Types -------------------------------------------------------------*/
/* Exported Variables Defines-------------------------------------------------*/
/* Private Variables ---------------------------------------------------------*/
/* Private Function Prototypes -----------------------------------------------*/
/* Function Defines ----------------------------------------------------------*/

/** @brief  		ģ���ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void dev_Init(void)
{
	devAgvBat_Init();                 //��س�ʼ��
	devStaBus_Init();
	devMp3_Init();
	devLit_Init();
	devTIM310_Init();                 //��ײ�״��ʼ��
	devAntiBar_Init();                //��ײ����ʼ��
	devEmergencyButton_Init();        //��ͣ��ť��ʼ��
	devCardReader_Init();             //��������ʼ��
	devPcCommunication_Init();        //���ػ�ͨ�ų�ʼ��
	devRemoteControl_Init();          //ң������ʼ��
	devSteeringWheel_Init();          //���ֳ�ʼ��
}

/** @brief  		ѭ������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void dev_Loop(void)
{
	static u16 s_Cnt = 0;
	
	s_Cnt++;
	
	//1ms
	devStaBus_Loop();
	
	//10ms
	if(s_Cnt % 10 == 0)
	{
		devTim310_Loop();
    devAntiBar_Loop();
		devEmergencyButton_Loop();
		devCardReader_Loop();
	}
	
	//20ms
	if(s_Cnt % 20 == 0)
	{
		//devCardReader_Loop();
		devSteeringWheel_Loop();
		devPcCommunication_Loop();
	}
	
	//30ms
	if(s_Cnt % 30 == 0)
	{
		devMp3_Loop();
		devLit_Loop();
		devRemoteControl_Loop();
	}
	
	//100ms
	if(s_Cnt % 100 == 0)
	{
		devAgvBat_Loop();
	}
}

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
