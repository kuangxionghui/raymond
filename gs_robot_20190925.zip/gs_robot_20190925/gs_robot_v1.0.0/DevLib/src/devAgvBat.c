/**
  ******************************************************************************
  * @file    devAntiBar.c
  * @author  kuang
  * @version V1.0.0
  * @date    2019-06-17
  * @brief   ���ļ��ǵ��bmsģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "devAgvBat.h"
#include "bspGPIO.h"
#include "bsp.h"
#include "sys.h"

/* Private Macro -------------------------------------------------------------*/

#define LOW_POWER_ALARM     30

#define NO_CHARGE_STATE   0x00
#define CHARGING_STATE  0x01

#define STABUS_RXCHECKBIT	  0X0001	//���ռ��λ

/* Private Types -------------------------------------------------------------*/
AgvBat_T s_agvBat;

/** @brief  		ģ���ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devAgvBat_Init(void)
{
	s_agvBat.Enable = 1;
	s_agvBat.LowPowerFlag = 0;
	s_agvBat.SetAlarm = LOW_POWER_ALARM;
	s_agvBat.Power = 0;
	s_agvBat.Status = NO_CHARGE_STATE;
}

/** @brief  		ѭ������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devAgvBat_Loop(void)
{	
	//ʹ��
	if(s_agvBat.Enable == 0)
		return;
	
	checkAgvBatProcess();
}

/** @brief  	������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void checkAgvBatProcess(void)
{
	devAgvBat_TxData();
	devAgvBat_RxData();
}

/** @brief  	��������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devAgvBat_TxData(void)
{
	u8 len;
	
	len = 6;
	s_agvBat.Cmd[0] = 0x7F;
	s_agvBat.Cmd[1] = 0x10;
	s_agvBat.Cmd[2] = 0x02;
	s_agvBat.Cmd[3] = 0x06;
	s_agvBat.Cmd[4] = 0x11;
	s_agvBat.Cmd[5] = 0x58;
	
	bspUsart_PutStr(SERIAL_PORT1,s_agvBat.Cmd,len);
}

/** @brief  	��������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devAgvBat_RxData(void)
{
	u8* buf;
	u16 len;
	
	//����
	if(bspUsart_GetStr(SERIAL_PORT1, STABUS_RXCHECKBIT, &buf, &len))
		return;

	//��ǰͨ���豸
  checkPower_RxData(buf, len);
}

/** @brief  		����
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */

u8 bat_rec[50];



void checkPower_RxData(u8 buf[], u16 len)
{
  u8 current_power_h;
  u8 current_power_l;
  u8 total_power_h;
  u8 total_power_l;
	float total_power;
	float current_power;
	float bat_power;
	u8 i;
	
	for(i=0;i<30;i++)
  {
		bat_rec[i] = buf[i];
	}	
	
	if(len != 27)
		return;
	
	if(buf[0] != 0x7F)  //head
		return;
	
	if(buf[1] != 0x10)  //add
		return;
	
  if((buf[5] & 0x01) == 0x01)
	{
		s_agvBat.Status = CHARGING_STATE;
	}
	else
	{
		s_agvBat.Status = NO_CHARGE_STATE;
	}
	
	current_power_h = buf[22];
	current_power_l = buf[21];
	
	total_power_h = buf[24];
	total_power_l = buf[23];
	
	current_power = ((current_power_h&0x00FF)<<8)+current_power_l;
	total_power = ((total_power_h&0x00FF)<<8)+total_power_l;
	bat_power = ((current_power/total_power)*100.0);
	s_agvBat.Power = (u8)bat_power;
}

/************* (C) COPYRIGHT 2019 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
