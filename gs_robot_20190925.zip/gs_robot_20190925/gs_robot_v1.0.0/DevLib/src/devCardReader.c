/**
  ******************************************************************************
  * @file    devCardReader.c
  * @author  kuang
  * @version V1.0.0
  * @date    2019-06-17
  * @brief   ���ļ���ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "devCardReader.h"
#include "bsp.h"
#include "devPcCommunication.h"
#include "devSteeringWheel.h"

/* Private Macro -------------------------------------------------------------*/
#define STABUS_RXCHECKBIT	  0X0001	//���ռ��λ

/* Private Types -------------------------------------------------------------*/
ReadCard_T s_readCard;
extern SteerWheel_T s_steerWheel;
extern PcCom_T s_pcCom;

u16 test_readIdCount = 0;

/** @brief  		ģ���ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devCardReader_Init(void)
{
	s_readCard.Enable = 1;
	s_readCard.ID_h = 0;
	s_readCard.ID_l = 0;
	s_readCard.Last_ID_h = 0;
	s_readCard.Last_ID_l = 0;
	s_readCard.Status = 0;
}

/** @brief  		ѭ������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devCardReader_Loop(void)
{	
	//ʹ��
	if(s_readCard.Enable == 0)
		return;
	
	checkCardReaderProcess();
	
}
/** @brief  		������������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void checkCardReaderProcess(void)
{
	devCardRead_TxData();
	devCardRead_RxData();
}

/** @brief  		��������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devCardRead_TxData(void)
{
	u8 len;
	
	s_readCard.Cmd[0] = 0x52;
	s_readCard.Cmd[1] = 0x43;
	s_readCard.Cmd[2] = 0x6F;
	s_readCard.Cmd[3] = 0x64;
	s_readCard.Cmd[4] = 0x65;
	s_readCard.Cmd[5] = 0x00;
	s_readCard.Cmd[6] = 0x3F;
	s_readCard.Cmd[7] = 0xFD;
	len = 8;
	
	bspUsart_PutStr(SERIAL_PORT4,s_readCard.Cmd,len);
}

/** @brief  		 ��������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devCardRead_RxData(void)
{
	u8* buf;
	u16 len;
	
	//����
	if(bspUsart_GetStr(SERIAL_PORT4, STABUS_RXCHECKBIT, &buf, &len))
		return;

	//��ǰͨ���豸
  checkCardReader_RxData(buf, len);
}

/** @brief  		 ��������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void checkCardReader_RxData(u8 buf[], u16 len)
{
	u8 card_id_h;
	u8 card_id_l;
	static u8 card_energy = 0;
		
	if(len != 18)
		return;
	
	if((buf[0] != 0x52) || (buf[1] != 0x43) ||(buf[2] != 0x6f) || (buf[3] != 0x64) || (buf[4] != 0x65))  //head
		return;
	
	card_id_l = buf[8];
	card_id_h = buf[9];
	s_readCard.Energy = buf[7];
	
	s_readCard.Current_ID_h = card_id_h;
	s_readCard.Current_ID_l = card_id_l;
	
	if(s_steerWheel.Vel_x > 300)
	{
		card_energy = 0;
	}
	else
	{
		card_energy = 4;
	}
	//�ж��Ƿ����µĿ�������
	if(s_readCard.Energy > card_energy)
	{
		if((s_readCard.Last_ID_h != card_id_h)||(s_readCard.Last_ID_l != card_id_l))
		{
			s_readCard.ID_h = card_id_h;
			s_readCard.ID_l = card_id_l;
			s_readCard.Last_ID_h = s_readCard.ID_h;
			s_readCard.Last_ID_l = s_readCard.ID_l;
			s_readCard.GetNewCard = 1;
		}
  }
}


/************* (C) COPYRIGHT 2019 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
