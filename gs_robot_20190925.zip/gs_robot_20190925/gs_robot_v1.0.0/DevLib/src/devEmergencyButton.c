/**
  ******************************************************************************
  * @file    devEmergencyButton.c
  * @author  kuang
  * @version V1.0.0
  * @date    2019-06-17
  * @brief   ���ļ���ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "devEmergencyButton.h"
#include "bsp.h"
#include "bspGPIO.h"
#include "devSteeringWheel.h"
/* Private Macro -------------------------------------------------------------*/


/* Private Types -------------------------------------------------------------*/
Emergency_T s_emergency;
extern GPIO_T s_GPIO;
extern SteerWheel_T s_steerWheel;

u8 moto_init_flag = 0;

/** @brief  		ģ���ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devEmergencyButton_Init(void)
{
	s_emergency.Enable = 1;
	s_emergency.count = 0;
	s_emergency.flag = 0;
	s_emergency.Value = 0;
}

/** @brief  		ѭ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */

void devEmergencyButton_Loop(void)
{
	static u16 s_cnt = 0;
	
	if(s_emergency.Enable == 0)
		return;
	
	s_emergency.Value = s_GPIO.X[1] & 0x02;
	if(s_emergency.Value == 0x00)
	{
		s_emergency.count++;
		if(s_emergency.count >= 10)   //100ms�����ֹ����
		{
			s_emergency.count = 0;
			s_emergency.flag = 1;
			moto_init_flag = 1;
		}
	}
	else
	{
		if(moto_init_flag == 1)
		{
			s_cnt++;
			if(s_cnt > 300)
			{
				s_cnt = 0;
				moto_init_flag = 0;
			  s_steerWheel.ResetFlag = 1;
			}
		}
		s_emergency.count = 0;
		s_emergency.flag = 0;
	}
}

/************* (C) COPYRIGHT 2019 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
