/**
  ******************************************************************************
  * @file    devPcCommunication.c
  * @author  kuang
  * @version V1.0.0
  * @date    2019-06-17
  * @brief   ���ļ���ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "devPcCommunication.h"
#include "bsp.h"
#include <stdio.h>
#include <string.h>
#include "devTim310.h"
#include "devAntiBar.h"
#include "devEmergencyButton.h"
#include "app.h"
#include "devAgvBat.h"
#include "devCardReader.h"
#include "devSteeringWheel.h"
/* Private Macro -------------------------------------------------------------*/
#define STABUS_RXCHECKBIT	  0X0001	//���ռ��λ
#define COM_HEAD      0xFF
#define COM_PC_ADD    0x01
#define COM_MCU_ADD   0x02
/* Private Types -------------------------------------------------------------*/
PcCom_T s_pcCom;
extern Tim310 s_tim310;
extern AntiBar s_antiBar;
extern Emergency_T s_emergency;
extern App_T s_app;
extern AgvBat_T s_agvBat;
extern ReadCard_T s_readCard;
extern SteerWheel_T s_steerWheel;
/** @brief  		ģ���ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devPcCommunication_Init(void)
{
	memset(&s_pcCom,0,sizeof(s_pcCom));
	s_pcCom.Enable = 1;
	s_pcCom.ArrivedFlag = 0;
	s_pcCom.StartFlag = 1; 
	s_pcCom.CtrMode = 0x01;
	s_pcCom.PickUp = 0;
}

/** @brief  		ѭ������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devPcCommunication_Loop(void)
{	
	//ʹ��
	if(s_pcCom.Enable == 0)
		return;
	s_pcCom.TimeOutCnt++;
	if(s_pcCom.TimeOutCnt>100)
	{
		s_pcCom.TimeOutFlag = 1;
	}
	PcCommunicationProcess();
}

/** @brief  		PCͨ�Ŵ�������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void PcCommunicationProcess(void)
{
	devPcCommunication_RxData();
	if(s_pcCom.CheckAckFlag == 1)
	{
		s_pcCom.CheckAckCount++;
		if(s_pcCom.CheckAckCount > 50)
		{
			s_pcCom.CheckAckError = 1;
		}
	}
}

/** @brief  		���ͺ���
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devPcCommunication_TxData(void)
{
	u8 len;

	//ʹ��
	len = 8;
	
	if(s_pcCom.Enable == 0)
	{
		len = 0;
		return;
	}
	
	devPcCommunication_Updata();

	bspUsart_PutStr(SERIAL_PORT5,s_pcCom.SendBuf,len);
}

/** @brief  		��������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devPcCommunication_Updata(void)
{
	u8 check_sum;
	
	s_pcCom.SendBuf[0] = COM_HEAD;
	s_pcCom.SendBuf[1] = COM_PC_ADD;
	s_pcCom.SendBuf[2] = s_pcCom.SendCmd;
	s_pcCom.SendBuf[3] = s_pcCom.SendData[0];
	s_pcCom.SendBuf[4] = s_pcCom.SendData[1];
	s_pcCom.SendBuf[5] = s_pcCom.SendData[2];
	s_pcCom.SendBuf[6] = s_pcCom.SendData[3];
	check_sum = (s_pcCom.SendBuf[1] + s_pcCom.SendBuf[2] + s_pcCom.SendBuf[3] + s_pcCom.SendBuf[4] + s_pcCom.SendBuf[5] + s_pcCom.SendBuf[6])&0xFF;
	s_pcCom.SendBuf[7] = check_sum;
}

/** @brief  		���պ���
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void devPcCommunication_RxData(void)
{
	u8* buf;
	u16 len;
	
	//����
	if(bspUsart_GetStr(SERIAL_PORT5, STABUS_RXCHECKBIT, &buf, &len))
		return;

	//��ǰͨ���豸
  PcCommunication_RxData(buf, len);
}

/** @brief  		��������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void PcCommunication_RxData(u8 buf[], u8 len)
{
	u8 i;
	u8 check_sum;
	
	if(len != 8)
		return;
	
	if(buf[0] != COM_HEAD)
		return;
	
	if(buf[1] != COM_MCU_ADD)
		return;
	
  check_sum = ((buf[1] + buf[2] + buf[3] + buf[4] + buf[5] + buf[6])&0xFF);
	
	if(check_sum != buf[7])
		return;
	
	s_pcCom.TimeOutFlag = 0;
	s_pcCom.TimeOutCnt = 0;
	
	s_pcCom.ReceiveFlag = 1;
	
	for(i=0; i<len; i++)
	{
		s_pcCom.RecBuf[i] = buf[i];
	}
	switch(s_pcCom.RecBuf[2])
	{
		case 0x01:                             //����
			if(s_pcCom.RecBuf[3] == 0x00)
			{
				s_pcCom.StartFlag = 0;
			}
			else if(s_pcCom.RecBuf[3] == 0x01)
			{
				s_pcCom.StartFlag = 1;
			}
			
			s_pcCom.SendCmd = 0x01;
			s_pcCom.SendData[0] = 0xFF;
			s_pcCom.SendData[1] = 0xFF;
			s_pcCom.SendData[2] = 0xFF;
			s_pcCom.SendData[3] = 0xFF;
			devPcCommunication_TxData();
			break;
			
		case 0x02:                              //��������
			if(s_pcCom.StartFlag == 1)
			{
				s_pcCom.TaskIdx = s_pcCom.RecBuf[3];
				s_pcCom.Vel_x = s_pcCom.RecBuf[4];
				s_pcCom.TargetCard_h = s_pcCom.RecBuf[5];
				s_pcCom.TargetCard_l = s_pcCom.RecBuf[6];
				s_pcCom.NavRunFlag = 1;	
			}
			s_pcCom.TaskCompleteFlag = 0;
			s_pcCom.SendCmd = 0x02;
			s_pcCom.SendData[0] = 0xFF;
			s_pcCom.SendData[1] = 0xFF;
			s_pcCom.SendData[2] = 0xFF;
			s_pcCom.SendData[3] = 0xFF;
			devPcCommunication_TxData();
			break;	
			
		case 0x03:                                           //�ϴ�agv״̬�����ػ�
			s_pcCom.SendCmd = 0x03;
		  if(s_tim310.Obstacle == 0)   //�ϰ���״̬
			{
				s_pcCom.SendData[0] = s_pcCom.SendData[0]&0xFE;
			}
			else
			{
				s_pcCom.SendData[0] = s_pcCom.SendData[0]|0x01;
			}
			
			if(s_steerWheel.ErrorFlag == 0)
			{
				s_pcCom.SendData[0] = s_pcCom.SendData[0]&0xFD;  //���״̬
			}
			else
			{
				s_pcCom.SendData[0] = s_pcCom.SendData[0]|0x02;
			}
			
			if(s_app.OutWayFlag == 0)   //�ѹ�״̬
			{
				s_pcCom.SendData[0] = s_pcCom.SendData[0]&0xFB;
			}
			else
			{
				s_pcCom.SendData[0] = s_pcCom.SendData[0]|0x04;
			}
			
			if(s_readCard.Energy == 0)   //��״̬
			{
				s_pcCom.SendData[0] = s_pcCom.SendData[0]&0xF7;
			}
			else
			{
				s_pcCom.SendData[0] = s_pcCom.SendData[0]|0x08;
			}
			
			if(s_emergency.flag == 0)   //��ͣ״̬
			{
				s_pcCom.SendData[0] = s_pcCom.SendData[0]&0xEF;
			}
			else
			{
				s_pcCom.SendData[0] = s_pcCom.SendData[0]|0x10;
			}
			
			if(s_antiBar.flag == 0)   //��ײ״̬
			{
				s_pcCom.SendData[0] = s_pcCom.SendData[0]&0xDF;
			}
			else
			{
				s_pcCom.SendData[0] = s_pcCom.SendData[0]|0x20;
			}
			
			if((s_steerWheel.SensorFlag_f == 0x00)&&(s_steerWheel.SensorFlag_l == 0x00)&&(s_steerWheel.SensorFlag_r == 0x00)) //�Ƿ��ڴ�����
			{
				s_pcCom.SendData[0] = s_pcCom.SendData[0]|0x40;
			}
			else
			{
				s_pcCom.SendData[0] = s_pcCom.SendData[0]&0xBF;
			}
			
			if(s_pcCom.TaskCompleteFlag == 0)    //�������״̬
			{
				s_pcCom.SendData[0] = s_pcCom.SendData[0]&0x7F;
			}
			else
			{
				s_pcCom.SendData[0] = s_pcCom.SendData[0]|0x80;
			}
			
			s_pcCom.SendData[1] = s_readCard.Current_ID_h;
			s_pcCom.SendData[2] = s_readCard.Current_ID_l;
			s_pcCom.SendData[3] = s_agvBat.Power;
			devPcCommunication_TxData();
      break;
		
		case 0x04:                               //ģʽ�л�
			if(s_pcCom.StartFlag == 1)
			{	
				if(s_pcCom.RecBuf[3] == 0x00)
				{
					s_pcCom.CtrMode = 0x00;    
					s_pcCom.Vel_x = 0;				
					s_steerWheel.CtlMode = s_pcCom.CtrMode;
				}
				else if(s_pcCom.RecBuf[3] == 0x01)
				{
					s_pcCom.CtrMode = 0x01;
					s_pcCom.Vel_x = 0;
					s_steerWheel.CtlMode = s_pcCom.CtrMode;
				}
				else if(s_pcCom.RecBuf[3] == 0x02)
				{
					s_pcCom.CtrMode = 0x02;
					s_pcCom.Vel_x = 0;
					s_steerWheel.CtlMode = s_pcCom.CtrMode;
				}
		  }
			s_pcCom.SendCmd = 0x04;
			s_pcCom.SendData[0] = 0xFF;
			s_pcCom.SendData[1] = 0xFF;
			s_pcCom.SendData[2] = 0xFF;
			s_pcCom.SendData[3] = 0xFF;
			devPcCommunication_TxData();
			break;
			
		case 0x05:                               //������ң������
			if(s_pcCom.StartFlag == 1)
			{
				if(s_pcCom.CtrMode == 0x02)
				{	
				
					s_pcCom.PanelRemoto = s_pcCom.RecBuf[3];
					s_pcCom.Vel_x = s_pcCom.RecBuf[4];
				}
		  }
			s_pcCom.SendCmd = 0x05;
			s_pcCom.SendData[0] = 0xFF;
			s_pcCom.SendData[1] = 0xFF;
			s_pcCom.SendData[2] = 0xFF;
			s_pcCom.SendData[3] = 0xFF;
			devPcCommunication_TxData();
			break;
			
		case 0x06:                              //����������
			if(s_pcCom.StartFlag == 1)
      {
				if(s_pcCom.RecBuf[3] == 0)            //����
				{
					s_pcCom.SlowFlag = 1;
				}
				else if(s_pcCom.RecBuf[3] == 1)       //�����ٶ�
				{
					s_pcCom.SlowFlag = 0;
				}
				else if(s_pcCom.RecBuf[3] == 2)       //��խͨ��
				{
					s_pcCom.PickUp = 1;
				}
				else if(s_pcCom.RecBuf[3] == 3)       //��խͨ��
				{
					s_pcCom.PickUp = 0;
				}
				else if(s_pcCom.RecBuf[3] == 4)       //ȥ�ֿ�
				{
					s_pcCom.GetGoods = 1;
				}
				else if(s_pcCom.RecBuf[3] == 5)       //���ֿ�
				{
					s_pcCom.GetGoods = 0;
				}
				else if(s_pcCom.RecBuf[3] == 6)       //���ֿ�
				{
					s_pcCom.Getboard = 1;
				}
				else if(s_pcCom.RecBuf[3] == 7)       //���ֿ�
				{
					s_pcCom.Getboard = 0;
				}
				else if(s_pcCom.RecBuf[3] == 8)       //��ʼ������
				{
					s_pcCom.SlowFlag = 0;
					s_pcCom.PickUp = 0;
					s_pcCom.Getboard = 0;
					s_pcCom.CtrMode = 0x01;
					s_pcCom.Vel_x = 0;
					s_steerWheel.CtlMode = s_pcCom.CtrMode;
					s_antiBar.flag = 0;
					s_app.OutWayFlag = 0;
					s_emergency.flag = 0;
					s_steerWheel.ErrorFlag = 0;
					s_tim310.Obstacle = 0;
					s_pcCom.PauseFlag = 0;
					s_steerWheel.EncodeCnt_1 = 0;
				}
				else if(s_pcCom.RecBuf[3] == 9)
				{
					s_pcCom.PauseFlag = 1;
				}
				else if(s_pcCom.RecBuf[3] == 10)
				{
					s_pcCom.PauseFlag = 0;
				}
		  }
			s_pcCom.SendCmd = 0x06;
			s_pcCom.SendData[0] = 0xFF;
			s_pcCom.SendData[1] = 0xFF;
			s_pcCom.SendData[2] = 0xFF;
			s_pcCom.SendData[3] = 0xFF;
			devPcCommunication_TxData();
			break;
			
		case 0x07:                              //���������Ϣ
			if(s_pcCom.StartFlag == 1)
      {
				if(s_pcCom.RecBuf[3] == 1) 
				{
					s_pcCom.PcAlarmFlag = 0;
				  s_antiBar.flag = 0;
				}
				if(s_pcCom.RecBuf[4] == 1) 
				{
					s_app.OutWayFlag = 0;
				  s_steerWheel.ResetFlag = 1;
				}
		  }
		  s_pcCom.SendCmd = 0x07;
			s_pcCom.SendData[0] = 0xFF;
			s_pcCom.SendData[1] = 0xFF;
			s_pcCom.SendData[2] = 0xFF;
			s_pcCom.SendData[3] = 0xFF;
			devPcCommunication_TxData();
			break;
		
		case 0x08:                             //��λ������
			if(s_pcCom.StartFlag == 1)
      {
				s_pcCom.PcAlarmFlag = 1;
		  }
		  s_pcCom.SendCmd = 0x08;
			s_pcCom.SendData[0] = 0xFF;
			s_pcCom.SendData[1] = 0xFF;
			s_pcCom.SendData[2] = 0xFF;
			s_pcCom.SendData[3] = 0xFF;
			devPcCommunication_TxData();
			break;
		
		case 0x09:                             //���ֱ�����Ϣ
			s_pcCom.SendCmd = 0x09;
			s_pcCom.SendData[0] = s_steerWheel.MFIOError;   
			s_pcCom.SendData[1] = s_steerWheel.FrontError;
			s_pcCom.SendData[2] = s_steerWheel.BackError;
		  if(s_pcCom.PauseFlag == 0)   //��ͣ״̬
			{
				s_pcCom.SendData[3] = s_pcCom.SendData[3]&0xFE;
			}
			else
			{
				s_pcCom.SendData[3] = s_pcCom.SendData[3]|0x01;
			}
			
			if(s_pcCom.CtrMode == 0)   //��ǰ����ģʽ
			{
				s_pcCom.SendData[3] = s_pcCom.SendData[3]&0xFB;
			}
			else if(s_pcCom.CtrMode == 1)
			{
				s_pcCom.SendData[3] = s_pcCom.SendData[3]&0xFB;
				s_pcCom.SendData[3] = s_pcCom.SendData[3]|0x02;
			}
			else if(s_pcCom.CtrMode == 2)
			{
				s_pcCom.SendData[3] = s_pcCom.SendData[3]&0xFB;
				s_pcCom.SendData[3] = s_pcCom.SendData[3]|0x04;
			}
			
			devPcCommunication_TxData();
			break;
			
		case 0x0A:
			s_pcCom.SendCmd = 0x0A;
		  s_pcCom.SendData[0] = (u8)(s_steerWheel.EncodeCnt_1&0x000000FF);   
			s_pcCom.SendData[1] = (u8)((s_steerWheel.EncodeCnt_1&0x0000FF00)>>8);
			s_pcCom.SendData[2] = (u8)((s_steerWheel.EncodeCnt_1&0x00FF0000)>>16);
		  s_pcCom.SendData[3] = (u8)((s_steerWheel.EncodeCnt_1&0xFF000000)>>24);
		  devPcCommunication_TxData();
			break;
	}
}

/************* (C) COPYRIGHT 2019 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
