/**
  ******************************************************************************
  * @file    devTim310.h
  * @author  kuang
  * @version V1.0.0
  * @date    2019-06-17
  * @brief   ���ļ���ģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DEV_TIM310_H
#define __DEV_TIM310_H

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
	 
/* Exported Macro ------------------------------------------------------------*/
/* Exported Types ------------------------------------------------------------*/
typedef struct
{
	u8		FrontEnable;		//ǰ�״�ʹ��
	u8		BackEnable;		  //���״�ʹ��
//	u8    LeftEnable;     //���״�ʹ��
//	u8    RightEnable;    //���״�ʹ��
	u8		FrontValue;     //ǰ�״�����
	u8    BackValue;      //���״�����
//	u8    LeftValue;      //���״�����
//	u8    RightValue;     //���״�����
	u8    Obstacle;       //�ϰ�����
	u8    BackSlowlyValue;//���پ���
	u8    BackStopValue;  //ֹͣ����
	u8    FrontSlowlyValue;//���پ���
	u8    FrontStopValue;  //ֹͣ����
}Tim310;
/* Exported Variables --------------------------------------------------------*/
/* Exported Function Prototypes ----------------------------------------------*/
void devTIM310_Init(void);
void devTim310_Loop(void);
u8 checkTim310Front(void);
u8 checkTim310Back(void);
//u8 checkWrLeft(void);
//u8 checkWrRight(void);
#ifdef __cplusplus
}
#endif

#endif /* __DEV_TIM310_H */ 

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
