/**
  ******************************************************************************
  * @file    devCardReader.h
  * @author  kuang
  * @version V1.0.0
  * @date    2019-06-17
  * @brief   ���ļ���ģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DEV_CARDREADER_H
#define __DEV_CARDREADER_H

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
	 
/* Exported Macro ------------------------------------------------------------*/
/* Exported Types ------------------------------------------------------------*/
typedef struct
{
	u8      Enable;        //ʹ��
	u8      Status;        //״̬
	u8      ID_h;          //��id�Ÿ�λ
	u8      ID_l;          //��id�ŵ�λ
	u8      Last_ID_h;     //��һ��id
	u8      Last_ID_l;     //��һ��id
	u8      Cmd[8];        //����״̬
	u8      Energy;        //�ź�ǿ��
	u8      Current_ID_h;  //��ǰ����λ
	u8      Current_ID_l;  //��ǰ����λ
	u8      GetNewCard;    
}ReadCard_T;
/* Exported Variables --------------------------------------------------------*/
/* Exported Function Prototypes ----------------------------------------------*/
void devCardReader_Init(void);
void devCardReader_Loop(void);
void checkCardReaderProcess(void);
void devCardRead_TxData(void);
void devCardRead_RxData(void);
void checkCardReader_RxData(u8 buf[], u16 len);
#ifdef __cplusplus
}
#endif

#endif /* __DEV_CARDREADER_H */ 

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
