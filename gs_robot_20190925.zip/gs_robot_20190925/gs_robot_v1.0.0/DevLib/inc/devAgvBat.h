/**
  ******************************************************************************
  * @file    devAgvBat.h
  * @author  kuang
  * @version V1.0.0
  * @date    2019-06-17
  * @brief   ���ļ���ģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __DEVAGVBAT_H__
#define __DEVAGVBAT_H__

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
	 
/* Exported Macro ------------------------------------------------------------*/
/* Exported Types ------------------------------------------------------------*/
typedef struct
{
	float 	Voltage;		  //��ѹ V
	float	  Current;		  //���� A
	float	  Temperature;	//�¶� C
	u8		  Power;			  //���� 0-100%
	u16     SetAlarm;     //���ñ�������
	u8		  LowPowerFlag; //�͵���������־
	u8      Enable;       //ʹ��
	u8      Status;       //״̬
	u8      Cmd[6];       //����״̬
}AgvBat_T;
/* Exported Variables --------------------------------------------------------*/
/* Exported Function Prototypes ----------------------------------------------*/

void devAgvBat_Init(void);
void devAgvBat_Loop(void);
void checkAgvBatProcess(void);
void devAgvBat_TxData(void);
void devAgvBat_RxData(void);
void checkPower_RxData(u8 buf[], u16 len);

#ifdef __cplusplus
}
#endif
	 
#endif


