/**
  ******************************************************************************
  * @file    devMp3.h
  * @author  Zzl
  * @version V1.0.0
  * @date    2017-11-25
  * @brief   ���ļ���ģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ���������ơ�
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DEV_MP3_H
#define __DEV_MP3_H

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
	 
/* Exported Macro ------------------------------------------------------------*/
/* Exported Types ------------------------------------------------------------*/
/* Exported Variables --------------------------------------------------------*/
/* Exported Function Prototypes ----------------------------------------------*/
void devMp3_ParInit(void);
void devMp3_Init(void);
void devMp3_SysEnSet(u8 en);
void devMp3_UserSet(u8 chl, u8 vol);
void devMp3_SysSet(u8 chl);
u8   devMp3_GetLinkFault(void);
void devMp3_RxData(u8 buf[], u16 len);
void devMp3_TxData(u8 buf[], u16 *len);
void devMp3_Loop(void);

#ifdef __cplusplus
}
#endif

#endif /* __DEV_MP3_H */ 

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
