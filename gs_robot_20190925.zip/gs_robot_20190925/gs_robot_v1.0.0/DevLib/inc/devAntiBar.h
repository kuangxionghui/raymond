/**
  ******************************************************************************
  * @file    devAntiBar.h
  * @author  kuang
  * @version V1.0.0
  * @date    2019-06-17
  * @brief   ���ļ���ģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DEV_ANTIBAR_H
#define __DEV_ANTIBAR_H

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
	 
/* Exported Macro ------------------------------------------------------------*/
/* Exported Types ------------------------------------------------------------*/
typedef struct
{
	u8		Enable;		   //ʹ��
	u8		Value;       //��־
	u8    flag;        //��־
	u16   count;       //����
}AntiBar;
/* Exported Variables --------------------------------------------------------*/
/* Exported Function Prototypes ----------------------------------------------*/
void devAntiBar_Init(void);
void devAntiBar_Loop(void);
	 
#ifdef __cplusplus
}
#endif

#endif /* __DEV_ANTIBAR_H */ 

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
