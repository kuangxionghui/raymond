/**
  ******************************************************************************
  * @file    dev.h
  * @author  Zzl
  * @version V1.0.0
  * @date    2017-11-25
  * @brief   ���ļ���ģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ���������ơ�
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DEV_H
#define __DEV_H

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "devBat.h"
#include "devStaBus.h"
#include "devMp3.h"
#include "devLit.h"
#include "devTim310.h"	
#include "devAntiBar.h"
#include "devEmergencyButton.h"
#include "devCardReader.h"
#include "devPcCommunication.h"
#include "devRemoteControl.h"
#include "devSteeringWheel.h"
#include "devAgvBat.h"

/* Exported Macro ------------------------------------------------------------*/
/* Exported Types ------------------------------------------------------------*/
/* Exported Variables --------------------------------------------------------*/
/* Exported Function Prototypes ----------------------------------------------*/
void dev_Init(void);
void dev_Loop(void);

#ifdef __cplusplus
}
#endif

#endif /* __DEV_H */ 

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
