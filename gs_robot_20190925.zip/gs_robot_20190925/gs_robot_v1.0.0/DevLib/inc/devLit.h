/**
  ******************************************************************************
  * @file    devLit.h
  * @author  Zzl
  * @version V1.0.0
  * @date    2017-11-25
  * @brief   ���ļ���ģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ���������ơ�
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DEV_LIT_H
#define __DEV_LIT_H

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
	 
/* Exported Macro ------------------------------------------------------------*/
/* Exported Types ------------------------------------------------------------*/
typedef enum
{
	LIT_MODE_OFF	= 0,	//����ʾ
	LIT_MODE_FREE	= 1,	//����
	LIT_MODE_MOV_TM = 2,	//�˶�ֱ��
	LIT_MODE_MOV_TL = 3,	//�˶���ת
	LIT_MODE_MOV_TR = 4,	//�˶���ת
	LIT_MODE_MOV_SL = 5,	//�˶�����
	LIT_MODE_MOV_SR = 6,	//�˶�����
	LIT_MODE_OP		= 7,	//����
	LIT_MODE_RED_CL	= 8,	//��Ƴ���
	LIT_MODE_RED_SX	= 9,	//�����˸
	LIT_MODE_YEL_CL = 10,	//�ƵƳ���
	LIT_MODE_YEL_SX = 11,	//�Ƶ���˸
	LIT_MODE_RFID	= 12,	//����
	LIT_MODE_RUN_ST	= 13,	//����
	LIT_MODE_ST		= 14,	//վ���л�
	LIT_MODE_ROUTE	= 15,	//·���л�
	LIT_MODE_YEL_HX	= 16,	//�Ƶƺ�����
}LIT_MODE_E;

/* Exported Variables --------------------------------------------------------*/
/* Exported Function Prototypes ----------------------------------------------*/
void devLit_ParInit(void);
void devLit_Init(void);
u8   devLit_GetLinkFault(void);
void devLit_SetDisMode(u8 mode);
u8   devLit_GetDisMode(void);
void devLit_RxData(u8 buf[], u16 len);
void devLit_TxData(u8 buf[], u16 *len);
void devLit_Loop(void);

#ifdef __cplusplus
}
#endif

#endif /* __DEV_LIT_H */ 

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
