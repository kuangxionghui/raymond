/**
  ******************************************************************************
  * @file    devRemoteControl.h
  * @author  kuang
  * @version V1.0.0
  * @date    2019-06-17
  * @brief   ���ļ���ģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DEV_REMOTECONTROL_H
#define __DEV_REMOTECONTROL_H

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
	 
/* Exported Macro ------------------------------------------------------------*/
#define MODE_NAV     0x01
#define MODE_OUTLINE 0x00
#define MODE_FUN     0x02
	 
#define BUTTON_NOTHING		0
#define BUTTON_FORWORD     2
#define BUTTON_BACK     128
#define BUTTON_DIRFT_LEFT     8
#define BUTTON_DIRFT_RIGHT     32
#define BUTTON_TURN     16
#define BUTTON_DIRFT_LEFT_45  1
#define BUTTON_DIRFT_RIGHT_45 4
#define BUTTON_DIRFT_LEFT_135 64
#define BUTTON_DIRFT_RIGHT_135 256
	 
#define REMOTO_HEAD_CODE    0xF1
#define REMOTE_ID           0x01
#define REMOTO_FUN_CODE     0x02
#define REMOTO_END_CODE     0xF3

/* Exported Types ------------------------------------------------------------*/
typedef struct
{
	u8      Enable;        //ʹ��
	u8      ErrorFlag;     //����������־
	u8      LinkFlag;      //���ӱ�־
	u8      ModeRf;        //ң��ģʽ
	s8      Spin;          //��ת����
	s16     Vel_x;        //�ٶ�x ��λ
	s16     Vel_y;        //�ٶ�x ��λ
	s16     Vel_w;        //�ٶ�y ��λ
	u16     ButtonValue;        //����ֵ
	u8      FindCard;     //��ǰ�ҿ�
}RemoteCtl_T;
/* Exported Variables --------------------------------------------------------*/
/* Exported Function Prototypes ----------------------------------------------*/
void devRemoteControl_Init(void);
void devRemoteControl_RxData(u8 buf[], u16 len);
void devRemoteControl_Loop(void);
void devRemoteControl_TxData(u8 buf[], u16 *len);
void check_outline_control(void);
void check_fun_control(void);
void fun_button_process(void);
#ifdef __cplusplus
}
#endif

#endif /* __DEV_REMOTECONTROL_H */ 

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
