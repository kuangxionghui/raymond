/**
  ******************************************************************************
  * @file    devBat.h
  * @author  Zzl
  * @version V1.0.0
  * @date    2017-11-25
  * @brief   ���ļ���ģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ���������ơ�
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DEV_BAT_H
#define __DEV_BAT_H

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
	 
/* Exported Macro ------------------------------------------------------------*/
#define DEVBAT_ALARM_LOW	0X01
#define DEVBAT_ALARM_STP	0X02
	 
/* Exported Types ------------------------------------------------------------*/
/* Exported Variables --------------------------------------------------------*/
/* Exported Function Prototypes ----------------------------------------------*/
void  devBat_ParInit(void);
void  devBat_Init(void);
void  devBat_RstAlarm(void);
u16   devBat_GetAlarm(void);
u16   devBat_GetPower(void);
float devBat_GetVol(void);
float devBat_GetTemp(void);
void  devBat_Loop(void);

#ifdef __cplusplus
}
#endif

#endif /* __DEV_BAT_H */ 

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
