/**
  ******************************************************************************
  * @file    bspADC.c
  * @author  Zzl
  * @version V1.0.0
  * @date    2016-03-10
  * @brief   ���ļ���ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ�������
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "bspADC.h"

/* Private Macro -------------------------------------------------------------*/ 
#define ADC1_DR_ADDRESS     ((uint32_t)0x4001244C)		//ADC1���ݻ���ַ
#define ADC_VALUE_MAX		4095						//ADC���ֵ
#define ADC_VER_INT			1.20f						//�ڲ��ο���ѹ
#define ADC_VER_VCC			3.30f						//�ⲿ�ο���ѹ
#define ADC_FIlTER_CNT		128							//��ֵ�˲�����
#define ADC_CH_NUM 			6							//ADC1ͨ����
#define ADC_CH_TOTAL		(ADC_CH_NUM + 2)			//��ADCͨ����

/* Private Types -------------------------------------------------------------*/
typedef struct
{
	float 	Value[ADC_CH_TOTAL];		//����·Ϊ�ⲿ����ͨ��
}ADC_T;

/* Exported Variables Defines-------------------------------------------------*/
/* Private Variables ---------------------------------------------------------*/
__IO uint16_t s_ADCConvertedValue[ADC_FIlTER_CNT][ADC_CH_NUM];	//����
ADC_T s_ADC;													//ADCֵ

/* Private Function Prototypes -----------------------------------------------*/
/* Function Defines ----------------------------------------------------------*/

/** @brief  		ADC��ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sADC_Init(void)
{
	NVIC_InitTypeDef 	NVIC_InitStructure;
	GPIO_InitTypeDef 	GPIO_InitStructure;
	ADC_InitTypeDef 	ADC_InitStructure;
	DMA_InitTypeDef 	DMA_InitStructure;
	u8 i;
	
	RCC_ADCCLKConfig(RCC_PCLK2_Div8);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1 | RCC_APB2Periph_GPIOC, ENABLE);
	
 	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 \
								| GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	//NVIC
	NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	/* DMA1 channel1 configuration ----------------------------------------------*/
	DMA_DeInit(DMA1_Channel1);
	DMA_InitStructure.DMA_PeripheralBaseAddr = ADC1_DR_ADDRESS;
	DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)s_ADCConvertedValue;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
	DMA_InitStructure.DMA_BufferSize = ADC_CH_NUM * ADC_FIlTER_CNT;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA1_Channel1, &DMA_InitStructure);

	/* Enable DMA1 channel1 */
	DMA_Cmd(DMA1_Channel1, ENABLE);
	
	//����DMA��������ж�
	DMA_ITConfig(DMA1_Channel1, DMA_IT_TC, ENABLE);
	
	/* ADC1 configuration ------------------------------------------------------*/
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
	ADC_InitStructure.ADC_ScanConvMode = ENABLE;
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStructure.ADC_NbrOfChannel = ADC_CH_NUM;
	ADC_Init(ADC1, &ADC_InitStructure);

	ADC_TempSensorVrefintCmd(ENABLE); //�����ڲ��¶ȴ�����
		
	/* ADC1 regular channel14 configuration */
	//ADC_SampleTime_239Cycles5 ʱԼ18usת��һ��
	i = 1;
	ADC_RegularChannelConfig(ADC1, ADC_Channel_17, i ++, ADC_SampleTime_239Cycles5); //VRE
	ADC_RegularChannelConfig(ADC1, ADC_Channel_16, i ++, ADC_SampleTime_239Cycles5); //TEMP
	
	ADC_RegularChannelConfig(ADC1, ADC_Channel_13, i ++, ADC_SampleTime_239Cycles5); //ADV
	ADC_RegularChannelConfig(ADC1, ADC_Channel_10, i ++, ADC_SampleTime_239Cycles5); //IN1
	ADC_RegularChannelConfig(ADC1, ADC_Channel_11, i ++, ADC_SampleTime_239Cycles5); //IN2
	ADC_RegularChannelConfig(ADC1, ADC_Channel_12, i ++, ADC_SampleTime_239Cycles5); //IN3

	/* Enable ADC1 DMA */
	ADC_DMACmd(ADC1, ENABLE);

	/* Enable ADC1 */
	ADC_Cmd(ADC1, ENABLE);

	/* Enable ADC1 reset calibration register */   
	ADC_ResetCalibration(ADC1);
	/* Check the end of ADC1 reset calibration register */
	while(ADC_GetResetCalibrationStatus(ADC1));

	/* Start ADC1 calibration */
	ADC_StartCalibration(ADC1);
	/* Check the end of ADC1 calibration */
	while(ADC_GetCalibrationStatus(ADC1));
	 
	/* Start ADC1 Software Conversion */ 
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);	
}

/** @brief  		ģ���ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void bspADC_Init(void)
{
	//��ʼ��
	sADC_Init();
}

/** @brief  		ADC��ֵ�˲�
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sADC_Filter(__IO u16 *data_in, u16 len, float data_out[])
{
	u8 i, j;
	float sum;
	
	for(i = 0; i < len; i ++)
	{
		//ȡֵ
		sum = 0;
		for(j = 0; j < ADC_FIlTER_CNT; j ++)
			sum += *(data_in + j * len + i);
		
		//�˲�
		data_out[i] = sum / ADC_FIlTER_CNT; 
	}
}

/** @brief  		�жϷ�����
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void DMA1_Channel1_IRQHandler(void)
{
	if(DMA_GetITStatus(DMA1_IT_TC1) != RESET)
	{
		sADC_Filter(&(s_ADCConvertedValue[0][0]), ADC_CH_NUM, &s_ADC.Value[0]);
		DMA_ClearITPendingBit(DMA1_IT_TC1);
	}
}

/** @brief  		��ȡADCת��ֵ
  * @param[in]  	ch: ͨ��ֵ���ο�BSPADC_CHANNEL����
  * @param[out]		��
  * @retval 		ת�����
  * @note			��
  */
float bspADC_GetValue(BSPADC_CHANNEL ch)
{
	u8 i;

	i = (u8)ch - 1;
	
	if(i > ADC_CH_TOTAL)
		return 0;
	else
		return s_ADC.Value[i];
}

/** @brief  		��ȡͨ���ĵ�ѹֵ
  * @param[in]  	mode : ģʽ 0ʹ���ⲿ�ο���ѹ���� 1ʹ���ڲ��ο���ѹ����
					ch	 : ͨ��ֵ���ο�BSPADC_CHANNEL����
  * @param[out]		��
  * @retval 		��ѹֵ
  * @note			��
  */
float bspADC_GetVoltage(BSPADC_CHANNEL ch, u8 mode)
{ 
	if(mode == 0)
		return ADC_VER_VCC * bspADC_GetValue(ch) / ADC_VALUE_MAX;
	else
		return ADC_VER_INT * bspADC_GetValue(ch) / bspADC_GetValue(VRE);
}

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
