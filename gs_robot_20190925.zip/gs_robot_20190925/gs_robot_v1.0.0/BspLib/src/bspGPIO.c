/**
  ******************************************************************************
  * @file    bspGPIO.c
  * @author  Zzl
  * @version V1.0.0
  * @date    2016-03-10
  * @brief   ���ļ���ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ�������
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "bspGPIO.h"
#include "sys.h"

/* Private Macro -------------------------------------------------------------*/ 
#define GP_X00	PAin(0)
#define GP_X01	PAin(1)
#define GP_X02 	PBin(9)
#define GP_X03 	PBin(8)
#define GP_X04 	PBin(5)
#define GP_X05 	PCin(13)
#define GP_X06 	PCin(14)
#define GP_X07 	PCin(15)
#define GP_X10 	PAin(6)
#define GP_X11 	PAin(7)
#define GP_X12 	PBin(6)
#define GP_X13 	PBin(7)

#define GP_Y00 	PCout(6)
#define GP_Y01 	PCout(7)
#define GP_Y02 	PCout(8)
#define GP_Y03 	PCout(9)
#define GP_Y04 	PCout(5)
#define GP_Y05 	PBout(0)
#define GP_Y06	PBout(1)
#define GP_Y07	PBout(2)

/* Private Types -------------------------------------------------------------*/
/* Exported Variables Defines-------------------------------------------------*/
/* Private Variables ---------------------------------------------------------*/
GPIO_T s_GPIO;

/* Private Function Prototypes -----------------------------------------------*/
/* Function Defines ----------------------------------------------------------*/

/** @brief  		ģ���ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void bspGPIO_Init(void)
{	
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB \
						 | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD , ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);

	/*���*/  	
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 \
								| GPIO_Pin_2;
  	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_ResetBits(GPIOB, GPIO_InitStructure.GPIO_Pin);	

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6 \
								| GPIO_Pin_7 | GPIO_Pin_8 \
								| GPIO_Pin_9;
  	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_ResetBits(GPIOC, GPIO_InitStructure.GPIO_Pin);		

	/*����*/
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 \
								| GPIO_Pin_6 | GPIO_Pin_7;
  	GPIO_Init(GPIOA, &GPIO_InitStructure);	
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6 \
								| GPIO_Pin_7 | GPIO_Pin_8 \
								| GPIO_Pin_9;
  	GPIO_Init(GPIOB, &GPIO_InitStructure);	
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14 \
								| GPIO_Pin_15;
  	GPIO_Init(GPIOC, &GPIO_InitStructure);
}

/** @brief  		��ȡGPIOָ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
GPIO_T *bspGPIO_GetPtr(void)
{
	return &s_GPIO;
}

/** @brief  		дY�˿����
  * @param[in]  	portNum	:	�˿ں�
  					elcLevel: 	��� 0�� 1��
  * @param[out]		��
  * @retval 		0�ɹ� !0����
  * @note			��
  */
u8 bspGPIO_SetY(GPY_PORT_E portNum, u8 elcLevel)
{
	u8 num, index, port;

	port = (u8)portNum - 1;
	
	if(port > GPY_NUM)
		return 1;
	
	num   = port / 8;
	index = port % 8;

	if(elcLevel)
		s_GPIO.Y[num] |= 0X01 << index;
	else
		s_GPIO.Y[num] &= ~(0X01 << index);
	
	return 0;
}

/** @brief  		��Y�˿����
  * @param[in]  	portNum	:	�˿ں�
  * @param[out]		��
  * @retval 		elcLevel
  * @note			��
  */
u8 bspGPIO_GetY(GPY_PORT_E portNum)
{
	u8 num, index, port;

	port = (u8)portNum - 1;
	
	if(port > GPY_NUM)
		return 0;
	
	num   = port / 8;
	index = port % 8;
	
	return (s_GPIO.Y[num] >> index) & 0X01;
}

/** @brief  		дX�˿�����
  * @param[in]  	portNum	:	�˿ں�
  					elcLevel: 	��� 0�� 1��
  * @param[out]		��
  * @retval 		0�ɹ� !0����
  * @note			��
  */
u8 bspGPIO_SetX(GPX_PORT_E portNum, u8 elcLevel)
{
	u8 num, index, port;

	port = (u8)portNum - 1;
	
	if(port > GPX_NUM)
		return 1;
	
	num   = port / 8;
	index = port % 8;

	if(elcLevel)
		s_GPIO.X[num] |= 0X01 << index;
	else
		s_GPIO.X[num] &= ~(0X01 << index);
	
	return 0;
}

/** @brief  		��X�˿�����
  * @param[in]  	portNum	:	�˿ں�
  * @param[out]		��
  * @retval 		elcLevel
  * @note			��
  */
u8 bspGPIO_GetX(GPX_PORT_E portNum)
{
	u8 num, index, port;

	port = (u8)portNum - 1;
	
	if(port >= GPX_NUM)
		return 0;
	
	num   = port / 8;
	index = port % 8;
	
	return (s_GPIO.X[num] >> index) & 0X01;
}

/** @brief  		X�˿��������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sGPIO_XUpdate(void)
{
	u8 data;

	data = 0;
	if(GP_X00 == 0) data |= 0X01;
	if(GP_X01 == 0) data |= 0X02;
	if(GP_X02 == 0) data |= 0X04;
	if(GP_X03 == 0) data |= 0X08;
	if(GP_X04 == 0) data |= 0X10;
	if(GP_X05 == 0) data |= 0X20;
	if(GP_X06 == 0) data |= 0X40;
	if(GP_X07 == 0) data |= 0X80;
	s_GPIO.X[0] = data;
	
	data = s_GPIO.X[1] & 0XF0;
	if(GP_X10 == 0) data |= 0X01;
	if(GP_X11 == 0) data |= 0X02;
	if(GP_X12 == 0) data |= 0X04;
	if(GP_X13 == 0) data |= 0X08;
	s_GPIO.X[1] = data;
}  

/** @brief  		Y�˿��������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sGPIO_YUpdate(void)
{
	GP_Y00 =  s_GPIO.Y[0] & 0X01;
	GP_Y01 = (s_GPIO.Y[0] >> 1) & 0X01;
	GP_Y02 = (s_GPIO.Y[0] >> 2) & 0X01;
	GP_Y03 = (s_GPIO.Y[0] >> 3) & 0X01;
	GP_Y04 = (s_GPIO.Y[0] >> 4) & 0X01;
	GP_Y05 = (s_GPIO.Y[0] >> 5) & 0X01;
	GP_Y06 = (s_GPIO.Y[0] >> 6) & 0X01;
	GP_Y07 = (s_GPIO.Y[0] >> 7) & 0X01;
}  

/** @brief  		GPIOѭ������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			5ms
  */
void bspGPIO_Loop(void)
{	
	//����GPX
	sGPIO_XUpdate();	

	//�������
	sGPIO_YUpdate();
}

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
