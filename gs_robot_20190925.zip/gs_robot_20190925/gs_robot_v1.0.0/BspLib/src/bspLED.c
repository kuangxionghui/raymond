/**
  ******************************************************************************
  * @file    bspLED.c
  * @author  Zzl
  * @version V1.0.0
  * @date    2016-03-10
  * @brief   ���ļ���ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ�������
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "bspLED.h"
#include "sys.h"

/* Private Macro -------------------------------------------------------------*/
#define LED_ERR		PBout(3)	//����ָʾ��
#define LED_COM		PBout(4)	//ͨ��ָʾ��

/* Private Types -------------------------------------------------------------*/
typedef struct
{
	u16	ComTim;			//ͨ�ŵƵ���ʱ
	u16 ErrNum;			//�������˸��
	u8  LedCom;			//ͨ�ŵ�
	u8  LedErr;			//�����
	u8	NC2[10];		//����
}LED_T;

/* Exported Variables Defines-------------------------------------------------*/
/* Private Variables ---------------------------------------------------------*/
LED_T s_Led;

/* Private Function Prototypes -----------------------------------------------*/
/* Function Defines ----------------------------------------------------------*/

/** @brief  		ģ���ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void bspLED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB , ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);

	/*���*/
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4;
  	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_SetBits(GPIOB, GPIO_InitStructure.GPIO_Pin);

	s_Led.LedCom = LED_OFF;
	s_Led.LedErr = LED_OFF;
}

/** @brief  		����ErrLED��˸����
  * @param[in]  	num
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void bspLED_SetErrNum(u16 num)
{
	s_Led.ErrNum = num;
}

/** @brief  		LED��˸
  * @param[in]  	led : LED	
  					cnt : ��˸����
  * @param[out]		��
  * @retval 		��
  * @note			100ms ������һ��
  */
void sLED_Flash(u8 *led, u8 cnt)
{
	#define TIMER_HEOF 	 15
	#define TIMER_HEON   8
	#define TIMER_DATA   2
	
	static u16 s_Timer=0;
	static u8  s_Index=0;
	u16 timer_max;
	u8  index_max = cnt * 2 + 3;

	s_Index = s_Index % index_max;
	
	if(s_Index % 2)
		*led = LED_ON;
	else
		*led = LED_OFF;
	
	switch(s_Index)
	{
		case 0:
			timer_max = TIMER_HEOF;	
			break;
		case 1:
		case 2:
			timer_max = TIMER_HEON;	
			break;
		default:
			timer_max = TIMER_DATA;
			break;		
	}
		
	if(s_Timer < timer_max)
	{
		s_Timer ++;
	}
	else
	{
		s_Timer = 0;
		s_Index ++;
	}
}

/** @brief  		ѭ������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			100ms
  */
void bspLED_Loop(void)
{
	//�����
	sLED_Flash(&s_Led.LedErr, s_Led.ErrNum);

	//���
	LED_ERR = s_Led.LedErr;

	//ͨ�ŵ��ɴ��ڲ���ֱ��ʹ��
	//......
}

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
