/**
  ******************************************************************************
  * @file    bsp.c
  * @author  Zzl
  * @version V1.0.0
  * @date    2016-03-10
  * @brief   ���ļ���ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ�������
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "bsp.h"

/* Private Macro -------------------------------------------------------------*/
/* Private Types -------------------------------------------------------------*/
/* Exported Variables Defines-------------------------------------------------*/
/* Private Variables ---------------------------------------------------------*/
/* Private Function Prototypes -----------------------------------------------*/
/* Function Defines ----------------------------------------------------------*/

/** @brief  		ģ���ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void bsp_Init(void)
{
	//bspADC_Init();
	//bspDAC_Init();
	bspGPIO_Init();
	bspLED_Init(); 
	bspUsart_Init();
	//bspCan_Init();
}

/** @brief  		ѭ������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			1ms
  */
void bsp_Loop(void)
{
	static u16 s_Cnt = 0;
	
	s_Cnt++;
	
	//5ms
	if(s_Cnt % 5 == 0)
		bspGPIO_Loop();
	
	//50ms
	if(s_Cnt % 50 == 0)
    bspLED_Loop(); 

}

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
