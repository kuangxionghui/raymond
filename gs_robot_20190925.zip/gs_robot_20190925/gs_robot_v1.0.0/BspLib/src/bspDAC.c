/**
  ******************************************************************************
  * @file    bspDAC.c
  * @author  Zzl
  * @version V1.0.0
  * @date    2016-03-10
  * @brief   ���ļ���ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ�������
  * V1.0.1 �����ⲿ��չDAC
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "bspDAC.h"

/* Private Macro -------------------------------------------------------------*/
/* Private Types -------------------------------------------------------------*/
typedef struct
{
	u16 Value[2];		//DACֵ
	u8	NC[12];			//����
}DAC_T;

/* Exported Variables Defines-------------------------------------------------*/
/* Private Variables ---------------------------------------------------------*/
DAC_T s_DAC;

/* Private Function Prototypes -----------------------------------------------*/
/* Function Defines ----------------------------------------------------------*/

/** @brief  		ģ���ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void bspDAC_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	DAC_InitTypeDef DAC_InitType;

	//ʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
   	RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);

	//�˿�
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
 	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
 	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_SetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_5);

	//DAC
	DAC_InitType.DAC_Trigger = DAC_Trigger_None;
	DAC_InitType.DAC_WaveGeneration = DAC_WaveGeneration_None;
	DAC_InitType.DAC_LFSRUnmask_TriangleAmplitude = DAC_LFSRUnmask_Bit0;
	DAC_InitType.DAC_OutputBuffer = DAC_OutputBuffer_Disable ;

    DAC_Init(DAC_Channel_1,&DAC_InitType);
	DAC_Cmd(DAC_Channel_1, ENABLE); 
    DAC_SetChannel1Data(DAC_Align_12b_R, DAC_INIT_VALUE);
	
    DAC_Init(DAC_Channel_2,&DAC_InitType);
	DAC_Cmd(DAC_Channel_2, ENABLE);
    DAC_SetChannel2Data(DAC_Align_12b_R, DAC_INIT_VALUE);
}

/** @brief  		����DAC���
  * @param[in]  	ch	 : BSPDAC_CHANNEL
  * @param[in]  	value: ���ֵ 0-4095
  * @param[out]		��
  * @retval 		bit0 : ����ͨ������
			 		bit1 : ����ֵ���󣬵��������������Χ�����
  * @note			��
  */
u8 bspDAC_SetValue(DAC_CH_E ch, u16 value)
{
	u8 result=0;

	if(value > DAC_VALUE_MAX)
	{
		value = DAC_VALUE_MAX;
		result |= 0X02;
	}

	if(ch == CH1)
	{
		s_DAC.Value[0] = value;
		DAC_SetChannel1Data(DAC_Align_12b_R, value);
		
	}
	else if(ch == CH2)
	{
		s_DAC.Value[1] = value;
		DAC_SetChannel2Data(DAC_Align_12b_R, value);
	}
	else
	{
		result |= 0X01;;
	}

	return result;
}

/** @brief  		��ȡDAC���ֵ
  * @param[in]  	ch
  * @param[out]		��
  * @retval 		���ֵ
  * @note			��
  */
u16 bspDAC_GetValue(DAC_CH_E ch)
{
	if(ch == CH1)
		return s_DAC.Value[0];
	else if(ch == CH2)
		return s_DAC.Value[1];
	else
		return 0;
}

/** @brief  		ѭ������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			100ms
  */
void bspDAC_Loop(void)
{
	u8 i;
	
	for(i = 0; i < 2; i ++)
	{
		if(s_DAC.Value[i] > DAC_VALUE_MAX)
			s_DAC.Value[i] = DAC_VALUE_MAX;
	}
	
	DAC_SetChannel1Data(DAC_Align_12b_R, s_DAC.Value[0]);
	DAC_SetChannel2Data(DAC_Align_12b_R, s_DAC.Value[1]);
}
/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
