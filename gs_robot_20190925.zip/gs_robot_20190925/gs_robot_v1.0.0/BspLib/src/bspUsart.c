/**
  ******************************************************************************
  * @file    bspUsart.c
  * @author  Zzl
  * @version V2.0.0
  * @date    2016-03-10
  * @brief   ���ļ���ģ��Դ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ������ܡ�
  * V2.0.0 ��
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "bspUsart.h"
#include "sys.h"

/* Private Macro -------------------------------------------------------------*/
#define USARTTR_TX 				Bit_SET 
#define USARTTR_RX 				Bit_RESET
#define USARTLED_OFF 			Bit_SET 
#define USARTLED_ON 			Bit_RESET

#define USARTCONFIG_ENABLE		0X80000000
#define USARTCONFIG_RS485		0X00000100
#define USARTCONFIG_LEDEN		0X00000200

#define GPIO_Mode_USART_TX  	GPIO_Mode_AF_PP
#define GPIO_Speed_USART_TX		GPIO_Speed_50MHz

#define GPIO_Mode_USART_RX 		GPIO_Mode_IN_FLOATING

#define GPIO_Mode_USART_TR  	GPIO_Mode_Out_PP
#define GPIO_Speed_USART_TR		GPIO_Speed_50MHz

#define GPIO_Mode_USART_LED  	GPIO_Mode_Out_PP
#define GPIO_Speed_USART_LED 	GPIO_Speed_50MHz

#define USART_RXWAITTIME_KP		(10.0f * 10 * 1000 / USART_TIMER_TICK)
#define USART_TIMER_CNT			(USART_TIMER_TICK * 100 - 1)

#define USART_NUM_MAX			5

/* Private Types -------------------------------------------------------------*/
typedef struct
{
	USART_TypeDef* 	USARTx;				//���ں�
	GPIO_TypeDef* 	GPIO_TX;			//TX�˿ں�
	GPIO_TypeDef* 	GPIO_RX;			//RX�˿ں�
	GPIO_TypeDef* 	GPIO_LED;			//LED�˿ں�
	GPIO_TypeDef* 	GPIO_TR;			//TR�˿ں�
	u8*				RxBuf;				//���ջ���
	u16				RxBufSize;			//��������С
	u8				FrameTimMax;		//��֡ʱ��
	u8				IRQ_Num;			//�жϺ�
	u16				GPIO_Pin_TX;		//TX�˿ں�
	u16				GPIO_Pin_RX;		//RX�˿ں�	
	u16				GPIO_Pin_LED;		//LED�˿ں�
	u16				GPIO_Pin_TR;		//TR�˿ں�
	u32 			Baudrate;			//������
	u32				Config;				//����
}USART_PAR_T;

typedef struct
{
	u16 Index;							//��������
	u16 Length;							//buf����
	u16 SuccesFlag;						//�ɹ���־
	u8  LedTim;							//ָʾ��
	u8 	TimCnt;							//���ռ�ʱ
	u8	NC[8];							//����
}USART_RX_T;

typedef struct
{
	u8 	*Buf;							//����buf
	u16 Index;							//��������
	u16 Length;							//�������ݳ���
	u8  LedTim;							//ָʾ��
	u8 	Status;							//״̬ 0������ 1������
	u8	NC[6];							//����
}USART_TX_T;

typedef struct
{
	__IO USART_RX_T	 Rx;				//����
	__IO USART_TX_T	 Tx;				//����
}USART_T;

/* Exported Variables Defines-------------------------------------------------*/
/* Private Variables ---------------------------------------------------------*/

//��������
USART_PAR_T s_UsartPar[USART_NUM_MAX];

//�ڴ����
USART_T		s_Usart[USART_NUM_MAX];

//���ջ���
u8			s_UsartRxBuf[USART_NUM_MAX][128];

/* Private Function Prototypes -----------------------------------------------*/
/* Function Defines ----------------------------------------------------------*/

/** @brief  		������ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sUsart_ParInit(void)
{
	u8 i;
	
	//USART1
#if (USEUSART1 !=  USE_NO)
	i = 0;
	s_UsartPar[i].USARTx   		= USART1;
	s_UsartPar[i].Baudrate 		= USART1_BAUDRATE;
	s_UsartPar[i].IRQ_Num		= USART1_IRQn;
	s_UsartPar[i].GPIO_TX 		= GPIO_USART1_TX;
	s_UsartPar[i].GPIO_Pin_TX 	= GPIO_Pin_USART1_TX;	
	s_UsartPar[i].GPIO_RX 		= GPIO_USART1_RX;
	s_UsartPar[i].GPIO_Pin_RX 	= GPIO_Pin_USART1_RX;	
	s_UsartPar[i].GPIO_LED 		= GPIO_USART1_LED;
	s_UsartPar[i].GPIO_Pin_LED 	= GPIO_Pin_USART1_LED;
	s_UsartPar[i].GPIO_TR 		= GPIO_USART1_TR;
	s_UsartPar[i].GPIO_Pin_TR 	= GPIO_Pin_USART1_TR;
	s_UsartPar[i].RxBuf 		= &s_UsartRxBuf[i][0];
	s_UsartPar[i].RxBufSize 	= USART1_RXBUFFER_SIZE;
	s_UsartPar[i].FrameTimMax 	= USART_RXWAITTIME_KP / s_UsartPar[i].Baudrate + 1;
	s_UsartPar[i].Config 		= (i + 1) | USARTCONFIG_ENABLE;
	#if (USEUSART1 == USE_RS485)
		s_UsartPar[i].Config   |= USARTCONFIG_RS485;
	#endif
	#if (USEUSART1_LED != 0)
		s_UsartPar[i].Config   |= USARTCONFIG_LEDEN;
	#endif
	s_UsartPar[i].Config |= (u32)USART1_IRQPrePriority << 20;
	s_UsartPar[i].Config |= (u32)USART1_IRQSubPriority << 16;
#endif

	//USART2
#if (USEUSART2 !=  USE_NO)
	i = 1;
	s_UsartPar[i].USARTx   		= USART2;
	s_UsartPar[i].Baudrate 		= USART2_BAUDRATE;
	s_UsartPar[i].IRQ_Num		= USART2_IRQn;
	s_UsartPar[i].GPIO_TX 		= GPIO_USART2_TX;
	s_UsartPar[i].GPIO_Pin_TX 	= GPIO_Pin_USART2_TX;	
	s_UsartPar[i].GPIO_RX 		= GPIO_USART2_RX;
	s_UsartPar[i].GPIO_Pin_RX 	= GPIO_Pin_USART2_RX;	
	s_UsartPar[i].GPIO_LED 		= GPIO_USART2_LED;
	s_UsartPar[i].GPIO_Pin_LED 	= GPIO_Pin_USART2_LED;
	s_UsartPar[i].GPIO_TR 		= GPIO_USART2_TR;
	s_UsartPar[i].GPIO_Pin_TR 	= GPIO_Pin_USART2_TR;
	s_UsartPar[i].RxBuf 		= &s_UsartRxBuf[i][0];
	s_UsartPar[i].RxBufSize 	= USART2_RXBUFFER_SIZE;
	s_UsartPar[i].FrameTimMax 	= USART_RXWAITTIME_KP / s_UsartPar[i].Baudrate + 1;
	s_UsartPar[i].Config 		= (i + 1) | USARTCONFIG_ENABLE;
	#if (USEUSART2 == USE_RS485)
		s_UsartPar[i].Config   |= USARTCONFIG_RS485;
	#endif
	#if (USEUSART2_LED != 0)
		s_UsartPar[i].Config   |= USARTCONFIG_LEDEN;
	#endif
	s_UsartPar[i].Config |= (u32)USART2_IRQPrePriority << 20;
	s_UsartPar[i].Config |= (u32)USART2_IRQSubPriority << 16;
#endif

	//USART3
#if (USEUSART3 !=  USE_NO)
	i = 2;
	s_UsartPar[i].USARTx   		= USART3;
	s_UsartPar[i].Baudrate 		= USART3_BAUDRATE;
	s_UsartPar[i].IRQ_Num		= USART3_IRQn;
	s_UsartPar[i].GPIO_TX 		= GPIO_USART3_TX;
	s_UsartPar[i].GPIO_Pin_TX 	= GPIO_Pin_USART3_TX;	
	s_UsartPar[i].GPIO_RX 		= GPIO_USART3_RX;
	s_UsartPar[i].GPIO_Pin_RX 	= GPIO_Pin_USART3_RX;	
	s_UsartPar[i].GPIO_LED 		= GPIO_USART3_LED;
	s_UsartPar[i].GPIO_Pin_LED 	= GPIO_Pin_USART3_LED;
	s_UsartPar[i].GPIO_TR 		= GPIO_USART3_TR;
	s_UsartPar[i].GPIO_Pin_TR 	= GPIO_Pin_USART3_TR;
	s_UsartPar[i].RxBuf 		= &s_UsartRxBuf[i][0];
	s_UsartPar[i].RxBufSize 	= USART3_RXBUFFER_SIZE;
	s_UsartPar[i].FrameTimMax 	= USART_RXWAITTIME_KP / s_UsartPar[i].Baudrate + 1;
	s_UsartPar[i].Config 		= (i + 1) | USARTCONFIG_ENABLE;
	#if (USEUSART3 == USE_RS485)
		s_UsartPar[i].Config   |= USARTCONFIG_RS485;
	#endif
	#if (USEUSART3_LED != 0)
		s_UsartPar[i].Config   |= USARTCONFIG_LEDEN;
	#endif
	s_UsartPar[i].Config |= (u32)USART3_IRQPrePriority << 20;
	s_UsartPar[i].Config |= (u32)USART3_IRQSubPriority << 16;
#endif

	//USART4
#if (USEUSART4 !=  USE_NO)
	i = 3;
	s_UsartPar[i].USARTx   		= UART4;
	s_UsartPar[i].Baudrate 		= USART4_BAUDRATE;
	s_UsartPar[i].IRQ_Num		= UART4_IRQn;
	s_UsartPar[i].GPIO_TX 		= GPIO_USART4_TX;
	s_UsartPar[i].GPIO_Pin_TX 	= GPIO_Pin_USART4_TX;	
	s_UsartPar[i].GPIO_RX 		= GPIO_USART4_RX;
	s_UsartPar[i].GPIO_Pin_RX 	= GPIO_Pin_USART4_RX;	
	s_UsartPar[i].GPIO_LED 		= GPIO_USART4_LED;
	s_UsartPar[i].GPIO_Pin_LED 	= GPIO_Pin_USART4_LED;
	s_UsartPar[i].GPIO_TR 		= GPIO_USART4_TR;
	s_UsartPar[i].GPIO_Pin_TR 	= GPIO_Pin_USART4_TR;
	s_UsartPar[i].RxBuf 		= &s_UsartRxBuf[i][0];
	s_UsartPar[i].RxBufSize 	= USART4_RXBUFFER_SIZE;
	s_UsartPar[i].FrameTimMax 	= USART_RXWAITTIME_KP / s_UsartPar[i].Baudrate + 1;
	s_UsartPar[i].Config 		= (i + 1) | USARTCONFIG_ENABLE;
	#if (USEUSART4 == USE_RS485)
		s_UsartPar[i].Config   |= USARTCONFIG_RS485;
	#endif
	#if (USEUSART4_LED != 0)
		s_UsartPar[i].Config   |= USARTCONFIG_LEDEN;
	#endif
	s_UsartPar[i].Config |= (u32)USART4_IRQPrePriority << 20;
	s_UsartPar[i].Config |= (u32)USART4_IRQSubPriority << 16;
#endif

	//USART5
#if (USEUSART5 !=  USE_NO)
	i = 4;
	s_UsartPar[i].USARTx   		= UART5;
	s_UsartPar[i].Baudrate 		= USART5_BAUDRATE;
	s_UsartPar[i].IRQ_Num		= UART5_IRQn;
	s_UsartPar[i].GPIO_TX 		= GPIO_USART5_TX;
	s_UsartPar[i].GPIO_Pin_TX 	= GPIO_Pin_USART5_TX;	
	s_UsartPar[i].GPIO_RX 		= GPIO_USART5_RX;
	s_UsartPar[i].GPIO_Pin_RX 	= GPIO_Pin_USART5_RX;	
	s_UsartPar[i].GPIO_LED 		= GPIO_USART5_LED;
	s_UsartPar[i].GPIO_Pin_LED 	= GPIO_Pin_USART5_LED;
	s_UsartPar[i].GPIO_TR 		= GPIO_USART5_TR;
	s_UsartPar[i].GPIO_Pin_TR 	= GPIO_Pin_USART5_TR;
	s_UsartPar[i].RxBuf 		= &s_UsartRxBuf[i][0];
	s_UsartPar[i].RxBufSize 	= USART5_RXBUFFER_SIZE;
	s_UsartPar[i].FrameTimMax 	= USART_RXWAITTIME_KP / s_UsartPar[i].Baudrate + 1;
	s_UsartPar[i].Config 		= (i + 1) | USARTCONFIG_ENABLE;
	#if (USEUSART5 == USE_RS485)
		s_UsartPar[i].Config   |= USARTCONFIG_RS485;
	#endif
	#if (USEUSART5_LED != 0)
		s_UsartPar[i].Config   |= USARTCONFIG_LEDEN;
	#endif
	s_UsartPar[i].Config |= (u32)USART5_IRQPrePriority << 20;
	s_UsartPar[i].Config |= (u32)USART5_IRQSubPriority << 16;
#endif
}

/** @brief  		ʱ�ӳ�ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sUsart_ClkInit(void)
{
	//GPIO�˿�ʱ��ȫ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB\
						 | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD \
						 | RCC_APB2Periph_GPIOE | RCC_APB2Periph_GPIOF \
						 | RCC_APB2Periph_GPIOG, ENABLE);

	//����ʱ��
#if (USEUSART1 !=  USE_NO)
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
#endif

#if (USEUSART2 !=  USE_NO)
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
#endif

#if (USEUSART3 !=  USE_NO)
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
#endif

#if (USEUSART4 !=  USE_NO)
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);
#endif

#if (USEUSART5 !=  USE_NO)
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, ENABLE);
#endif
}

/** @brief  		���ڼ����ú���
  * @param[in]  	num : ���ں�
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sUsart_Config(SerialNum num)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure; 

	num --;
	
	//��ų���
	if(num >= USART_NUM_MAX)
		return;

	//δʹ��
	if((s_UsartPar[num].Config & USARTCONFIG_ENABLE) == 0)
		return;

	//TX
	GPIO_InitStructure.GPIO_Pin = s_UsartPar[num].GPIO_Pin_TX;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_USART_TX;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_USART_TX;
	GPIO_Init(s_UsartPar[num].GPIO_TX, &GPIO_InitStructure); 

	//RX
	GPIO_InitStructure.GPIO_Pin = s_UsartPar[num].GPIO_Pin_RX;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_USART_RX;
	GPIO_Init(s_UsartPar[num].GPIO_RX, &GPIO_InitStructure);

	//TR
	if(s_UsartPar[num].Config & USARTCONFIG_RS485)
	{
		GPIO_InitStructure.GPIO_Pin = s_UsartPar[num].GPIO_Pin_TR;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_USART_TR;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_USART_TR;
		GPIO_Init(s_UsartPar[num].GPIO_TR, &GPIO_InitStructure); 
		GPIO_WriteBit(s_UsartPar[num].GPIO_TR, s_UsartPar[num].GPIO_Pin_TR, USARTTR_RX);
	}

	//LED
	if(s_UsartPar[num].Config & USARTCONFIG_LEDEN)
	{
		GPIO_InitStructure.GPIO_Pin = s_UsartPar[num].GPIO_Pin_LED;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_USART_LED;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_USART_LED;
		GPIO_Init(s_UsartPar[num].GPIO_LED, &GPIO_InitStructure); 
		GPIO_WriteBit(s_UsartPar[num].GPIO_LED, s_UsartPar[num].GPIO_Pin_LED, USARTLED_OFF);
	}
	
	USART_DeInit(s_UsartPar[num].USARTx);
	
	/* USART1 mode config */
	USART_InitStructure.USART_BaudRate = s_UsartPar[num].Baudrate;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No ;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	
	USART_Init(s_UsartPar[num].USARTx, &USART_InitStructure);

	USART_ITConfig(s_UsartPar[num].USARTx, USART_IT_RXNE, ENABLE);
	
	/* Enable the USART1 Interrupt */
	NVIC_InitStructure.NVIC_IRQChannel = s_UsartPar[num].IRQ_Num;	 
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = (s_UsartPar[num].Config >> 20) & 0X0F;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = (s_UsartPar[num].Config >> 16) & 0X0F;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	USART_Cmd(s_UsartPar[num].USARTx, ENABLE);	
}

/** @brief  		�������ʹ�ö�ʱ����ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void sUsart_TimerInit(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseInitStruct;	

	RCC_APB1PeriphClockCmd(USART_TIMER_RCC, ENABLE);
	
	NVIC_InitStructure.NVIC_IRQChannel = USART_TIMER_IRQ;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	TIM_DeInit(USART_TIMER);
	TIM_TimeBaseInitStruct.TIM_Period = 719;   //100KHz  //ʱ�ӷ�Ƶ��
	TIM_TimeBaseInitStruct.TIM_Prescaler = USART_TIMER_CNT;  //2K //�������ڣ����� //0.2ms
	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1; 
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(USART_TIMER, &TIM_TimeBaseInitStruct);

	TIM_ClearFlag(USART_TIMER, TIM_FLAG_Update);
	TIM_ITConfig(USART_TIMER, TIM_IT_Update,ENABLE);
	TIM_Cmd(USART_TIMER, ENABLE);	
}

/** @brief  		�����жϺ���
  * @param[in]  	Usart
  * @param[out]		Usart
  * @retval 		��
  * @note			��
  */
void sUsart_IRQHandler(USART_PAR_T Par, USART_T *usart)
{
	u8 data=0;

	//ʹ��
	if((Par.Config & USARTCONFIG_ENABLE) == 0)
		return;
	
	//�쳣
	if(USART_GetFlagStatus(Par.USARTx, USART_FLAG_ORE) != RESET)
		data = Par.USARTx->DR;

	//����
	if(USART_GetITStatus(Par.USARTx, USART_IT_RXNE) != RESET)
	{
		data = Par.USARTx->DR;
		usart->Rx.TimCnt = 0;
		if(usart->Rx.Index < Par.RxBufSize)
		{
			Par.RxBuf[usart->Rx.Index] = data;
			usart->Rx.Index ++;
		}
	}

	//����
	if(USART_GetITStatus(Par.USARTx, USART_IT_TC) != RESET)
	{
		usart->Tx.Index ++;
		if(usart->Tx.Index < usart->Tx.Length)
		   	Par.USARTx->DR = usart->Tx.Buf[usart->Tx.Index];
		else
		{	
			USART_ITConfig(Par.USARTx, USART_IT_TC, DISABLE);
			usart->Tx.Status = 0;
			if(Par.Config & USARTCONFIG_RS485)
				GPIO_WriteBit(Par.GPIO_TR, Par.GPIO_Pin_TR, USARTTR_RX);
		}
	}
}

/** @brief  		����ʱ����ƺ���
  * @param[in]  	Usart
  * @param[out]		Usart
  * @retval 		��
  * @note			��
  */
void sUsart_Timer(USART_PAR_T Par, USART_T *usart)
{
	u8 flag=0;
	
	//ʹ��
	if((Par.Config & USARTCONFIG_ENABLE) == 0)
		return;
	
	//RX
	if(usart->Rx.Index)
	{
		if(usart->Rx.TimCnt < Par.FrameTimMax) 
		{
			usart->Rx.TimCnt ++;
		}
		else
		{
			usart->Rx.SuccesFlag = 0XFFFF;
			usart->Rx.Length = usart->Rx.Index;
			usart->Rx.LedTim = 250;
			usart->Rx.Index = 0;
		}
	}	

	//LED
	if(Par.Config & USARTCONFIG_LEDEN)
	{
		if(usart->Tx.LedTim)
		{
			usart->Tx.LedTim --;
			flag = 1;
		}

		if(usart->Rx.LedTim)
		{
			usart->Rx.LedTim --;
			flag = 1;
		}

		if(flag)
		{
			GPIO_WriteBit(Par.GPIO_LED, Par.GPIO_Pin_LED, USARTLED_ON);
		}
		else
		{
			GPIO_WriteBit(Par.GPIO_LED, Par.GPIO_Pin_LED, USARTLED_OFF);
		}
	}
}

/** @brief  		�������ʹ�ö�ʱ���жϷ������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void USART_TIMER_IRQHandler(void)
{
	u8 i;
	
	if(TIM_GetITStatus(USART_TIMER, TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(USART_TIMER, TIM_FLAG_Update);

		for(i = 0; i < USART_NUM_MAX; i ++)
			sUsart_Timer(s_UsartPar[i], &s_Usart[i]);
	}
}

/**************************************************************/

/** @brief  		�жϷ�����
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void USART1_IRQHandler(void)
{
	sUsart_IRQHandler(s_UsartPar[0], &s_Usart[0]);
}

/** @brief  		�жϷ�����
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void USART2_IRQHandler(void)
{
	sUsart_IRQHandler(s_UsartPar[1], &s_Usart[1]);
}

/** @brief  		�жϷ�����
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void USART3_IRQHandler(void)
{
	sUsart_IRQHandler(s_UsartPar[2], &s_Usart[2]);
}

/** @brief  		�жϷ�����
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void UART4_IRQHandler(void)
{
	sUsart_IRQHandler(s_UsartPar[3], &s_Usart[3]);
}

/** @brief  		�жϷ�����
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void UART5_IRQHandler(void)
{
	sUsart_IRQHandler(s_UsartPar[4], &s_Usart[4]);
}

/** @brief  		����ָ���������ݴ�
  * @param[in]  	num		: 	ָ�����ںţ��ο�SerialNum����
					buf[]	:	�������ݻ���
					len		:	�������ݳ���
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void bspUsart_PutStr(SerialNum num, u8 buf[], u16 len)
{
	num --;
	
	//��ų���
	if(num >= USART_NUM_MAX)
		return;

	//����Ϊ0
	if(len == 0)
		return;
	
	//δʹ��
	if((s_UsartPar[num].Config & USARTCONFIG_ENABLE) == 0)
		return;

	//æ
	if(s_Usart[num].Tx.Status != 0)
	{
		//�ȴ��������
		while(s_Usart[num].Tx.Status != 0)
			delay_us(2);

		//��֡
		delay_us(s_UsartPar[num].FrameTimMax * 100);
	}

	//���ݴ���
	s_Usart[num].Tx.Status = 1;
	s_Usart[num].Tx.LedTim = 250;
	s_Usart[num].Tx.Length = len;
	s_Usart[num].Tx.Buf = buf;
	s_Usart[num].Tx.Index = 0;

	//RS485
	if(s_UsartPar[num].Config & USARTCONFIG_RS485)
	{
		GPIO_WriteBit(s_UsartPar[num].GPIO_TR, s_UsartPar[num].GPIO_Pin_TR, USARTTR_TX);
		delay_us(10);
	}

	//���ڿ���
	while(USART_GetFlagStatus(s_UsartPar[num].USARTx, USART_FLAG_TXE) == RESET)
		delay_us(2);

	//���͵�һ�ֽ�
	s_UsartPar[num].USARTx->DR = s_Usart[num].Tx.Buf[0];
	USART_ITConfig(s_UsartPar[num].USARTx, USART_IT_TC, ENABLE);
}

/** @brief  		��ȡָ�����ڽ�������
  * @param[in]  	num		: ָ�����ںţ��ο�SerialNum����
  					checkBit: ���λ
  * @param[out]		buf		: �������ݻ���
					len		: �������ݳ���
  * @retval 		0�ɹ� !0ʧ��
  * @note			��
  */
u8 bspUsart_GetStr(SerialNum num, u16 checkBit, u8 **buf, u16 *len)
{
	num --;
	
	//��ų���
	if(num >= USART_NUM_MAX)
		return 0X80;

	//δʹ��
	if((s_UsartPar[num].Config & USARTCONFIG_ENABLE) == 0)
		return 0X40;

	//�����ձ�־
	if((s_Usart[num].Rx.SuccesFlag & checkBit) != checkBit)
		return 0X20;

	//����
	*len = s_Usart[num].Rx.Length;
	*buf = &s_UsartPar[num].RxBuf[0];

	//���־
	s_Usart[num].Rx.SuccesFlag &= ~checkBit;
	
	return 0;
}

/** @brief  		Usart��ʼ��
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void bspUsart_Init(void)
{
	u8 i;
	
	//ʱ��
	sUsart_ClkInit();	

	//��ʱ��
	sUsart_TimerInit();

	//����
	sUsart_ParInit();

	//��������
	for(i = 0; i < USART_NUM_MAX; i ++)
		sUsart_Config((SerialNum)(i + 1));
}

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
