/**
  ******************************************************************************
  * @file    bspGPIO.h
  * @author  Zzl
  * @version V1.0.0
  * @date    2016-03-10
  * @brief   ���ļ���ģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ���������ơ�
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BSP_GPIO_H
#define __BSP_GPIO_H

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "bsp.h"

/* Exported Macro ------------------------------------------------------------*/
#define GPX_NUM					64		//X�˿�����
#define GPY_NUM					64		//Y�˿�����

/* Exported Types ------------------------------------------------------------*/
typedef enum
{
	XNC = 0,
	X00 = 1,
	X01 = 2,
	X02 = 3,
	X03 = 4,
	X04 = 5,
	X05 = 6,
	X06 = 7,
	X07 = 8,
	X10 = 9,
	X11 = 10,
	X12 = 11,
	X13 = 12,
	X14 = 13,
	X15 = 14,
	X16 = 15,
	X17 = 16,
	//����Ϊ�ڲ�������
	X20 = 17,
	X21 = 18,
	X22 = 19,
	X23 = 20,
	X24 = 21,
	X25 = 22,
	X26 = 23,
	X27 = 24,
	X30 = 25,
	X31 = 26,
	X32 = 27,
	X33 = 28,
	X34 = 29,
	X35 = 30,
	X36 = 31,
	X37 = 32,
	X40 = 33,
	X41 = 34,
	X42 = 35,
	X43 = 36,
	X44 = 37,
	X45 = 38,
	X46 = 39,
	X47 = 40,
	X50 = 41,
	X51 = 42,
	X52 = 43,
	X53 = 44,
	X54 = 45,
	X55 = 46,
	X56 = 47,
	X57 = 48,
	X60 = 49,
	X61 = 50,
	X62 = 51,
	X63 = 52,
	X64 = 53,
	X65 = 54,
	X66 = 55,
	X67 = 56,
	X70 = 57,
	X71 = 58,
	X72 = 59,
	X73 = 60,
	X74 = 61,
	X75 = 62,
	X76 = 63,
	X77 = 64,
}GPX_PORT_E;	//��ͨ����

typedef enum
{
	YNC = 0,
	Y00 = 1,
	Y01 = 2,
	Y02 = 3,
	Y03 = 4,
	Y04 = 5,
	Y05 = 6,
	Y06 = 7,
	Y07 = 8,
	//����Ϊ�ڲ�������
	Y10 = 9,
	Y11 = 10,
	Y12 = 11,
	Y13 = 12,
	Y14 = 13,
	Y15 = 14,
	Y16 = 15,
	Y17 = 16,
	Y20 = 17,
	Y21 = 18,
	Y22 = 19,
	Y23 = 20,
	Y24 = 21,
	Y25 = 22,
	Y26 = 23,
	Y27 = 24,
	Y30 = 25,
	Y31 = 26,
	Y32 = 27,
	Y33 = 28,
	Y34 = 29,
	Y35 = 30,
	Y36 = 31,
	Y37 = 32,
	Y40 = 33,
	Y41 = 34,
	Y42 = 35,
	Y43 = 36,
	Y44 = 37,
	Y45 = 38,
	Y46 = 39,
	Y47 = 40,
	Y50 = 41,
	Y51 = 42,
	Y52 = 43,
	Y53 = 44,
	Y54 = 45,
	Y55 = 46,
	Y56 = 47,
	Y57 = 48,
	Y60 = 49,
	Y61 = 50,
	Y62 = 51,
	Y63 = 52,
	Y64 = 53,
	Y65 = 54,
	Y66 = 55,
	Y67 = 56,
	Y70 = 57,
	Y71 = 58,
	Y72 = 59,
	Y73 = 60,
	Y74 = 61,
	Y75 = 62,
	Y76 = 63,
	Y77 = 64,
}GPY_PORT_E;	//��ͨ���

typedef struct
{
	u8	X[8];			//��ͨ����
	u8  Y[8];			//��ͨ���
}GPIO_T;

/* Exported Variables --------------------------------------------------------*/
/* Exported Function Prototypes ----------------------------------------------*/
void bspGPIO_Init(void);
GPIO_T *bspGPIO_GetPtr(void);
u8 	 bspGPIO_SetY(GPY_PORT_E portNum, u8 elcLevel);
u8 	 bspGPIO_GetY(GPY_PORT_E portNum);
u8   bspGPIO_SetX(GPX_PORT_E portNum, u8 elcLevel);
u8 	 bspGPIO_GetX(GPX_PORT_E portNum);
void bspGPIO_Loop(void);
#ifdef __cplusplus
}
#endif

#endif /* __BSP_GPIO_H */ 

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
