/**
  ******************************************************************************
  * @file    bspUsart.h
  * @author  Zzl
  * @version V2.0.0
  * @date    2016-03-10
  * @brief   ���ļ���ģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ���������ơ�
  * V2.0.0 ��  
  	ע��: 
  	����GPIOʱҪע���Ƿ����������ܳ�ͻ������JTAG��
  	��ʱ���ⲿ�˿���ӳ���Լ��򿪸��ù���ʱ�ӡ�
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BSP_USART_H
#define __BSP_USART_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "stdio.h"

/* Exported Macro ------------------------------------------------------------*/

/*���ڹ��ܻ�����*/
#define USE_NO					0
#define USE_RS232				1
#define USE_RS485				2

//�û�������
/*************************************/
/*��ʱ��ѡ��*/
#define USART_TIMER				TIM2
#define USART_TIMER_RCC 		RCC_APB1Periph_TIM2
#define USART_TIMER_IRQ			TIM2_IRQn
#define USART_TIMER_IRQHandler	TIM2_IRQHandler
#define USART_TIMER_TICK		0.1		//ms

/*���ڹ���ѡ�� USE_NO/ USE_RS232/ USE_RS485*/
#define USEUSART1   			USE_RS485
#define USEUSART2   			USE_RS485
#define USEUSART3   			USE_RS485
#define USEUSART4   			USE_RS232
#define USEUSART5   			USE_RS232

/*����ָʾ�ƿ��� 0-1*/
#define USEUSART1_LED			0
#define USEUSART2_LED			0
#define USEUSART3_LED			1
#define USEUSART4_LED			0
#define USEUSART5_LED			0

/*����1����������*/
#define USART1_BAUDRATE			9600 
#define USART1_RXBUFFER_SIZE 	128
#define USART1_IRQPrePriority	1
#define USART1_IRQSubPriority	3

#define GPIO_USART1_TX			GPIOA
#define GPIO_Pin_USART1_TX 		GPIO_Pin_9

#define GPIO_USART1_RX			GPIOA
#define GPIO_Pin_USART1_RX 		GPIO_Pin_10

#define GPIO_USART1_TR			GPIOA
#define GPIO_Pin_USART1_TR 		GPIO_Pin_8

#define GPIO_USART1_LED			GPIOB
#define GPIO_Pin_USART1_LED 	GPIO_Pin_4

/*����2����������*/
#define USART2_BAUDRATE			115200
#define USART2_RXBUFFER_SIZE 	128
#define USART2_IRQPrePriority	1
#define USART2_IRQSubPriority	2

#define GPIO_USART2_TX			GPIOA
#define GPIO_Pin_USART2_TX 		GPIO_Pin_2

#define GPIO_USART2_RX			GPIOA
#define GPIO_Pin_USART2_RX 		GPIO_Pin_3

#define GPIO_USART2_TR			GPIOC
#define GPIO_Pin_USART2_TR 		GPIO_Pin_4

#define GPIO_USART2_LED			GPIOB
#define GPIO_Pin_USART2_LED 	GPIO_Pin_4

/*����3����������*/
#define USART3_BAUDRATE			115200
#define USART3_RXBUFFER_SIZE 	128
#define USART3_IRQPrePriority	1
#define USART3_IRQSubPriority	3

#define GPIO_USART3_TX			GPIOB
#define GPIO_Pin_USART3_TX 		GPIO_Pin_10

#define GPIO_USART3_RX			GPIOB
#define GPIO_Pin_USART3_RX 		GPIO_Pin_11

#define GPIO_USART3_TR			GPIOA
#define GPIO_Pin_USART3_TR 		GPIO_Pin_15

#define GPIO_USART3_LED			GPIOB
#define GPIO_Pin_USART3_LED 	GPIO_Pin_4

/*����4����������*/
#define USART4_BAUDRATE			115200
#define USART4_RXBUFFER_SIZE 	128
#define USART4_IRQPrePriority	1
#define USART4_IRQSubPriority	1

#define GPIO_USART4_TX			GPIOC
#define GPIO_Pin_USART4_TX 		GPIO_Pin_10

#define GPIO_USART4_RX			GPIOC
#define GPIO_Pin_USART4_RX 		GPIO_Pin_11

#define GPIO_USART4_TR			GPIOE
#define GPIO_Pin_USART4_TR 		GPIO_Pin_14

#define GPIO_USART4_LED			GPIOB
#define GPIO_Pin_USART4_LED 	GPIO_Pin_4

/*����5����������*/
#define USART5_BAUDRATE			115200
#define USART5_RXBUFFER_SIZE 	128
#define USART5_IRQPrePriority	1
#define USART5_IRQSubPriority	0

#define GPIO_USART5_TX			GPIOC
#define GPIO_Pin_USART5_TX 		GPIO_Pin_12

#define GPIO_USART5_RX			GPIOD
#define GPIO_Pin_USART5_RX 		GPIO_Pin_2

#define GPIO_USART5_TR			GPIOB
#define GPIO_Pin_USART5_TR 		GPIO_Pin_3

#define GPIO_USART5_LED			GPIOB
#define GPIO_Pin_USART5_LED 	GPIO_Pin_4
/*************************************/

/* Exported Types ------------------------------------------------------------*/
typedef enum
{ 
	SERIAL_PORT1 = 1,
	SERIAL_PORT2 = 2,
	SERIAL_PORT3 = 3,
	SERIAL_PORT4 = 4,
	SERIAL_PORT5 = 5,
}SerialNum;

/* Exported Variables --------------------------------------------------------*/
/* Exported Function Prototypes ----------------------------------------------*/
void bspUsart_PutStr(SerialNum num, u8 buf[], u16 len);
u8   bspUsart_GetStr(SerialNum num, u16 checkBit, u8 **buf, u16 *len);
void bspUsart_Init(void);
#ifdef __cplusplus
}
#endif

#endif /* __BSP_USART_H */ 
/************* (C) COPYRIGHT 2015 CASUN TECHNOLOGY CO.,LTD *****END OF FILE****/

