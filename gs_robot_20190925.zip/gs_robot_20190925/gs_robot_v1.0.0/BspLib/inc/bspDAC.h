/**
  ******************************************************************************
  * @file    bspDAC.h
  * @author  Zzl
  * @version V1.0.0
  * @date    2016-03-10
  * @brief   ���ļ���ģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ���������ơ�
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BSP_DAC_H
#define __BSP_DAC_H

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"

/* Exported Macro ------------------------------------------------------------*/
#define DAC_VALUE_MAX		4095
#define DAC_INIT_VALUE		0

/* Exported Types ------------------------------------------------------------*/
typedef enum
{
	CH1	= 1,
	CH2 = 2,
}DAC_CH_E;

/* Exported Variables --------------------------------------------------------*/
/* Exported Function Prototypes ----------------------------------------------*/
void bspDAC_Init(void);
u8   bspDAC_SetValue(DAC_CH_E ch, u16 value);
u16  bspDAC_GetValue(DAC_CH_E ch);
void bspDAC_Loop(void);

#ifdef __cplusplus
}
#endif

#endif /* __BSP_DAC_H */ 

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
