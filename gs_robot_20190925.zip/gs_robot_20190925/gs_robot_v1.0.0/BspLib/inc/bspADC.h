/**
  ******************************************************************************
  * @file    bspADC.h
  * @author  Zzl
  * @version V1.0.0
  * @date    2016-03-10
  * @brief   ���ļ���ģ��ͷ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ���������ơ�
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BSP_ADC_H
#define __BSP_ADC_H

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"

/* Exported Macro ------------------------------------------------------------*/

/* Exported Types ------------------------------------------------------------*/
typedef enum
{
	VRE		= 1,		//��׼��ѹͨ��
	TEMP	= 2,		//�¶�
	VCC		= 3,		//���ص�ѹ
	IN1		= 4,		//����ADC1
	IN2		= 5,		//����ADC2
	IN3		= 6,		//����ADC3
	IN4		= 7,		//�ⲿ����ֵ Ŀǰ��Ч
	INE		= 8,		//�ⲿ����ֵ Ŀǰ��Ч
}BSPADC_CHANNEL;

/* Exported Variables --------------------------------------------------------*/
/* Exported Function Prototypes ----------------------------------------------*/
void  bspADC_Init(void);
float bspADC_GetValue(BSPADC_CHANNEL ch);
float bspADC_GetVoltage(BSPADC_CHANNEL ch, u8 mode);

#ifdef __cplusplus
}
#endif

#endif /* __BSP_ADC_H */ 

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
