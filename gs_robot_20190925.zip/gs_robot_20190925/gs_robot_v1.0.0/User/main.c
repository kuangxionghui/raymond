/**
  ******************************************************************************
  * @file    main.c
  * @author  kuang
  * @version V1.0.0
  * @date    2019-06-14
  * @brief   ���ļ�������Դ�ļ���
  ******************************************************************************
  * @attention
  * V1.0.0 ��ɻ�������
  * <h2><center>&copy; COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "sys.h"
#include "bsp.h"
#include "dev.h"
#include "app.h"

/* Private Macro -------------------------------------------------------------*/ 
#define USER_WATHDOG	0

/* Private Types -------------------------------------------------------------*/
/* Exported Variables Defines-------------------------------------------------*/
/* Private Variables ---------------------------------------------------------*/
/* Private Function Prototypes -----------------------------------------------*/
/* Function Defines ----------------------------------------------------------*/

/** @brief  		���������
  * @param[in]  	��
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
int main(void)
{
	sys_Init();
	bsp_Init();	
	dev_Init();
	app_Init();
	
	delay_ms(200);	//�ȴ������ȶ�
#if  USER_WATHDOG
	sysWatchdog_Init(WatchDog_Prescaler, WatchDog_Counter);
#endif

	while(1)
  {
		if(sysTim_GetFlag())	//1ms
		{
			//sys_Loop();
			bsp_Loop();
			dev_Loop();
			app_Loop();
		}
#if  USER_WATHDOG
		sysWatchdog_ReloadCounter();
#endif
  }
}

#ifdef  USE_FULL_ASSERT
/** @brief  		���Դ���
  * @param[in]  	file
  * @param[in]  	line
  * @param[out]		��
  * @retval 		��
  * @note			��
  */
void assert_failed(uint8_t* file, uint32_t line)
{
	while (1)
	{
#if USED_DEBUG
		printf("\n [%s]: %d", file, line);
#endif		
	}
}
#endif

/************* (C) COPYRIGHT 2015 SZPT TECHNOLOGY CO.,LTD *****END OF FILE****/
